


<?php $__env->startSection('content'); ?>

<!-- start page title -->
<h1 class="app-page-title">Alarms</h1>
<!-- end page title -->

<div class="app-card app-card-orders-table h-100 shadow-sm">
  <div class="app-card-header p-3">
    <div class="row justify-content-between align-items-center">
      <div class="col-auto d-flex justify-content-between align-items-center">
        <h4 class="app-card-title">Alarms List</h4>
        <a href="<?php echo e(route('create_alarm')); ?>" class="btn app-btn-primary ms-3">Create Alarm</a>
      </div>
      <div class="col-auto">
        <?php
        if (isset($_GET['jan'])) {
          $year = '01';
        }
        if (isset($_GET['feb'])) {
          $year = '02';
        }
        if (isset($_GET['mar'])) {
          $year = '03';
        }
        if (isset($_GET['apr'])) {
          $year = '04';
        }
        if (isset($_GET['may'])) {
          $year = '05';
        }
        if (isset($_GET['jun'])) {
          $year = '06';
        }
        if (isset($_GET['jul'])) {
          $year = '07';
        }
        if (isset($_GET['aug'])) {
          $year = '08';
        }
        if (isset($_GET['sep'])) {
          $year = '09';
        }
        if (isset($_GET['oct'])) {
          $year = '10';
        }
        if (isset($_GET['nov'])) {
          $year = '11';
        }
        if (isset($_GET['filter'])) {
          $year = '07';
          // $year = 'filter';
        }
        if (isset($_GET['filter']) && isset($_GET['month'])) {
          $year = $_GET['month'];
          // echo $year;
          // $year = 'filter';
        }

        ?>
        <form class="d-flex align-items-center justify-content-end" method="get" action="">
          <select class="form-control year me-2" name="year" id="year" required>
            <option value="">Select Year</option>
            <option value="2000">2000</option>
            <option value="2001">2001</option>
            <option value="2002">2002</option>
            <option value="2003">2003</option>
            <option value="2004">2004</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
          </select>
          <select class="form-control month me-2" name="month" id="month" required>
            <option value="">Select month</option>
            <option value="01">January</option>
            <option value="02">Febrary</option>
            <option value="03">March</option>
            <option value="04">April</option>
            <option value="05">May</option>
            <option value="06">June</option>
            <option value="07">July</option>
            <option value="08">August</option>
            <option value="09">September</option>
            <option value="10">October</option>
            <option value="11">November</option>
            <option value="12">December</option>
          </select>
          <input class="btn app-btn-primary b" type="submit" name="filter" value="filter">
        </form>
      </div>
      <!--//col-->
    </div>
    <!--//row-->
  </div>
  <!--//app-card-header-->
  <div class="app-card-body p-4">
    <?php if(count($alarms) > 0): ?>
    <div class="table-responsive">
      <table id="datatable_users" class="table app-table-hover mb-0 text-left dt-table">
        <thead>
          <tr>
            <th class="cell ps-3">JOB No</th>
            <th class="cell">Date</th>
            <th class="cell">Alarm Monitoring Company</th>
            <th class="cell">Client Name</th>
            <th class="cell">Client Address</th>
            <th class="cell">Sector Activation</th>
            <th class="cell">Time On Site</th>
            <th class="cell">Time Off Site</th>
            <th class="cell">Document No</th>
            <th class="cell">Invoice To</th>
            <th class="cell">Comments</th>
            <th class="cell">Security Officers Name</th>
            <th class="cell pe-3">Delete</th>
          </tr>
        </thead>
        <tbody id="movie-data">
          <?php $__currentLoopData = $alarms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alarm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if (isset($_GET['year'])) {
            $month = $_GET['year'];
            $date = $month . '-' . $year;
            //die();
            if (strpos($alarm->date, $date) === false) {
              continue;
            }
          } ?>
          <tr>
            <td class="cell truncate"><?php echo e($alarm->job_no); ?></td>
            <td class="cell truncate">
              <span>
                <?php
                echo date("dS M, Y", strtotime($alarm->date));
                ?>
              </span>
              <span class="note">
                <?php
                echo date("h:m A", strtotime($alarm->date));
                ?>
              </span>
            </td>
            <td class="cell truncate"><?php echo e($alarm->alarm_monitor_company); ?></td>
            <td class="cell truncate"><?php echo e($alarm->client_name); ?></td>
            <td class="cell truncate"><?php echo e($alarm->client_address); ?></td>
            <td class="cell truncate"><?php echo e($alarm->sector_activation); ?></td>
            <td class="cell truncate"><?php echo e($alarm->time_on_site); ?></td>
            <td class="cell truncate"><?php echo e($alarm->time_off_site); ?></td>
            <td class="cell truncate"><?php echo e($alarm->document_no); ?></td>
            <td class="cell truncate"><?php echo e($alarm->invoice_to); ?></td>
            <td class="cell truncate"><?php echo e($alarm->comment); ?></td>
            <td class="cell truncate"><?php echo e($alarm->security_officer_name); ?></td>
            <td class="cell truncate">
              <a class="btn-sm app-btn-secondary border-danger text-danger mt-2 d-inline-block" href="<?php echo e(route('delete_alarm',$alarm->id)); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                </svg>
                <span class="d-none d-lg-inline-block">
                  Delete
                </span>
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="p-4">
      <div class="alert alert-info text-center mb-0" role="alert">
        No alarms found!
      </div>
    </div><!-- /.p-4 END -->
    <?php endif; ?>
  </div>
  <!--//app-card-body-->
</div>
<!--//app-card-->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  $(document).ready(function() {
    $('#year').on('change', function() {
      //alert(year);
    });
    $("button").click(function() {
      var year = $('#year').val();
      if (year == '') {
        alert('Select year!');
      }
      //alert(year);
      var month = (this.id); // or alert($(this).attr('id'));

      $.ajax({
        url: "<?php echo 'alarm/store_search'; ?>", //the page containing php script
        type: "get", //request type,
        dataType: 'html',
        data: {
          year: year,
          month: month
        },
        success: function(result) {
          alert('hr');
          //console.log(result.abc);
          $("#movie-data").append(result);
        }
      });









    });



  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OnGoing Projects\hometownsecurity-backup\resources\views/admin/alarm.blade.php ENDPATH**/ ?>