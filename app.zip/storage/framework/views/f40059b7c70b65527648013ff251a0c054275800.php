



<?php $__env->startSection('content'); ?>
<div class="content">          
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right"><a href="<?php echo e(route('create_alarm')); ?>" class="btn btn-primary">Create Alarm</a></div>
                <h4 class="page-title">Alarms</h4>
               
            </div>
         
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                   
                    <!-- Invoice Logo-->
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>JOB No</th>
                                <th>Date</th>
                                <th>Alarm Monitoring Company</th>
                                <th>Client Name</th>
                                <th>Client Address</th>
                                <th>Sector Activation</th>
                                <th>Time On Site</th>
                                <th>Time Off Site</th>
                                <th>Document No</th>
                                <th>Invoice To</th>
                                <th>Comments</th>
                                <th>Security Officers Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $alarms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alarm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($alarm->jon_no); ?></td>
                                <td><?php echo e($alarm->date); ?></td>
                                <td><?php echo e($alarm->alarm_monitor_company); ?></td>
                                <td><?php echo e($alarm->client_name); ?></td>
                                <td><?php echo e($alarm->client_address); ?></td>
                                <td><?php echo e($alarm->sector_activation); ?></td>
                                <td><?php echo e($alarm->time_on_site); ?></td>
                                <td><?php echo e($alarm->time_off_site); ?></td>
                                <td><?php echo e($alarm->document_no); ?></td>
                                <td><?php echo e($alarm->invoice_to); ?></td>
                                <td><?php echo e($alarm->comment); ?></td>
                                <td><?php echo e($alarm->security_officer_name); ?></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div><!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2021\June\Client\ClientManage\resources\views/alarm/index.blade.php ENDPATH**/ ?>