
<?php $__env->startSection('content'); ?>


<div class="content">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Dashboard</h4>
            </div>
        </div>
    </div>
<!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card widget-inline">
                <div class="card-body p-0">
                    <div class="row no-gutters">
                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0">
                                <div class="card-body text-center">
                                    <i class="dripicons-briefcase text-muted" style="font-size: 24px;"></i>
                                    <h3><span><?php echo e(count($notes)); ?></span></h3>
                                    <p class="text-muted font-15 mb-0">Total Notes</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0 border-left">
                                <div class="card-body text-center">
                                    <i class="dripicons-view-list-large text-muted" style="font-size: 24px;"></i>
                                    <h3><span><?php echo e(count($users)); ?></span></h3>
                                    <p class="text-muted font-15 mb-0">Total Users</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0 border-left">
                                <div class="card-body text-center">
                                    <i class="dripicons-user-group text-muted" style="font-size: 24px;"></i>
                                    <h3><span><?php echo e(count($clients)); ?></span></h3>
                                    <p class="text-muted font-15 mb-0">Total Clients</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0 border-left">
                                <div class="card-body text-center">
                                    <i class="dripicons-document-new text-muted" style="font-size: 24px;"></i>
                                    <h3><span><?php echo e(count($reports)); ?></span></h3>
                                    <p class="text-muted font-15 mb-0">Total Reports</p>
                                </div>
                            </div>
                        </div>

                    </div> <!-- end row -->
                </div>
            </div> <!-- end card-box-->
        </div> <!-- end col-->
    </div>
    <!-- end row-->

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-right">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#task_modal">New Task</button>
                    </div>
                    <h4 class="header-title mb-3">Tasks</h4>

                  
                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-hover mb-0">
                            <tbody>
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1"><a href="javascript:void(0);" class="text-body"><?php echo e($task->content); ?></a></h5>
                                        <span class="text-muted font-13"><?php echo e($task->created_at); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-muted font-13">Status</span> <br/>
                                        <span class="badge badge-warning-lighten"><?php echo e($task->status); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-muted font-13">Assigned to</span>
                                        <h5 class="font-14 mt-1 font-weight-normal"><?php echo e($task->name); ?></h5>
                                    </td>
                                    <?php if($task->status == "InComplete"): ?>
                                    <td>
                                        <a href="<?php echo e(route('department_task_complete', $task->id)); ?>" class="btn btn-primary">Complete</a>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <button  class="btn btn-success">Completed</button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div> <!-- end table-responsive-->

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>


    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                   
                    <h4 class="header-title mb-3">Recent Activities</h4>

                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-hover mb-0">
                            <tbody>
                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <span class="text-muted font-13"><?php echo e($section->content); ?></span> <br/>
                                    </td>
                                    <td class="table-action" style="width: 50px;">
                                    <?php echo e($section->created_at); ?>

                                    </td>
                                    <td class="table-action" style="width: 50px;">
                                        <a href="<?php echo e(route('delete_section',$section->id)); ?>" class="btn btn-primary">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div> <!-- end table-responsive-->

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    
</div>
<div id="task_modal" class="modal fade delete-modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <form method="POST" action="<?php echo e(route('department_task_client')); ?>" >
                    <?php echo csrf_field(); ?>
                    <div class="card-box">

                        <div class="form-group form-focus">
                        <label for="example-select">Contract Length</label>
                            <input type="text" name="content" class="form-control floating" required >
                        </div>
                        
                        <div class="form-group">
                            <label for="example-select">Users</label>
                            <select class="form-control" name="user_id" id="example-select" required>
                                <option selected>-- Select User --</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-0">
                            <button class="btn btn-primary" style="width:100%" type="submit">New Task</button>
                        </div>
                       
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.department', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/hometown/client.hometownsecurity.com.au/resources/views/department/index.blade.php ENDPATH**/ ?>