
<?php $__env->startSection('content'); ?>


<div class="content">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right"><a href="<?php echo e(route('admin_client')); ?>" class="btn btn-primary">Back</a></div>
                <h4 class="page-title">Show Client</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mt-0 mb-3">Client Information</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="text-left">
                                <p class="text-muted">
                                    <strong> Name : </strong>
                                    <span class="ml-2"><?php echo e($client->name); ?></span>
                                </p>
                                <p class="text-muted">
                                    <strong> Email : </strong>
                                    <span class="ml-2"><?php echo e($client->email); ?></span>
                                </p>
                                <p class="text-muted">
                                    <strong> Contact Number : </strong>
                                    <span class="ml-2"><?php echo e($client->phone); ?></span>
                                </p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="text-left">
                                <p class="text-muted">
                                    <strong> Payments : </strong>
                                    <span class="ml-2"><?php echo e($client->payment); ?></span>
                                </p>
                                <p class="text-muted">
                                    <strong> Payment Terms : </strong>
                                    <span class="ml-2"><?php echo e($client->payment_term); ?> Days</span>
                                </p>
                                <p class="text-muted">
                                    <strong> Invoice Period : </strong>
                                    <?php if($client->invoice_period == 0): ?>
                                    <span class="ml-2">End of Month</span>
                                    <?php else: ?>
                                    <span class="ml-2">Start of Month</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <div class="text-left">
                                <p class="text-muted">
                                    <strong> Patrols : </strong>
                                    <span class="ml-2"><?php echo e($client->patrol); ?></span>
                                </p>
                                <p class="text-muted">
                                    <strong> Days : </strong>
                                    <span class="ml-2"><?php echo e($client->days); ?> Days</span>
                                </p>
                                <p class="text-muted">
                                    <strong> Lock Up : </strong>
                                    <?php if($client->invoice_period == 0): ?>
                                    <span class="ml-2">Yes</span>
                                    <?php else: ?>
                                    <span class="ml-2">No</span>
                                    <?php endif; ?>
                                </p>
                                <p class="text-muted">
                                    <strong> Contract Length : </strong>
                                    <span class="ml-2"><?php echo e($client->contract_length); ?></span>
                                </p>
                                <p class="text-muted">
                                    <strong> Site Name : </strong>
                                    <span class="ml-2"><?php echo e($client->site_name); ?></span>
                                </p>
                                <p class="text-muted">
                                    <strong> Call Out Fee : </strong>
                                    <span class="ml-2"><?php echo e($client->call_out); ?></span>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                </div><!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <button style="margin:10px;" class="btn btn-primary" data-toggle="modal" data-target="#note_modal">Add Note</button>
                    <!-- Invoice Logo-->
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Content</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($note->content); ?></td>
                                <td><?php echo e($note->created_at); ?></td>
                                <td class="text-center">
                                   
                                   
                                    <a class="btn btn-danger btn-rounded" href="<?php echo e(route('delete_note',$note->id)); ?>"> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <button style="margin: 10px;" class="btn btn-primary" data-toggle="modal" data-target="#report_modal">Add Report</button>
                    <!-- Invoice Logo-->
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(asset($report->path)); ?>" target="_new" > <?php echo e($report->title); ?></a></td>
                                <td><?php echo e($report->created_at); ?></td>
                                <td class="text-center">
                                   
                                   
                                    <a class="btn btn-danger btn-rounded" href="<?php echo e(route('delete_report',$report->id)); ?>"> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- end row-->
    
</div>


<div id="note_modal" class="modal fade delete-modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <form method="POST" action="<?php echo e(route('admin_add_note')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-box">
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="profile-basic">
                                    <div class="row">
                                        <input type="hidden" name="id"   value="<?php echo e($client->id); ?>">
                                        <div class="col-md-12">
                                            <div class="form-group form-focus">
                                                <label class="focus-label">Note</label>
                                                <input type="text" name="content" class="form-control floating" required >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <button class="btn btn-primary" style="width:100%" type="submit">Add Note</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="report_modal" class="modal fade delete-modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <form method="POST" action="<?php echo e(route('admin_add_report')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-box">
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="profile-basic">
                                    <div class="row">
                                        <input type="hidden" name="id"   value="<?php echo e($client->id); ?>">
                                        <div class="col-md-12">
                                            <div class="form-group form-focus">
                                                <label class="focus-label">Title</label>
                                                <input type="text" name="title" class="form-control floating" required >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group form-focus">
                                                <label class="focus-label">File</label>
                                                <input type="file" name="pdf" class="form-control floating" required >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <button class="btn btn-primary" style="width:100%" type="submit">Add Report</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2021\June\Client\ClientManage\resources\views/admin/client_show.blade.php ENDPATH**/ ?>