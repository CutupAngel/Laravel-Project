
<?php $__env->startSection('content'); ?>


<div class="content">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
              
                <h4 class="page-title">Users</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-sm-4">
                            <a href="<?php echo e(route('admin_account_create')); ?>" class="btn btn-primary mb-2">Create User</a>
                        </div>
                    </div>
                    <!-- Invoice Logo-->
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Date</th>
                                <th>Actions</th>
                                
                            </tr>
                        </thead>


                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->role == 1): ?>
                                        Owner
                                        <?php elseif($user->role == 2): ?>
                                        Admin Account
                                        <?php elseif($user->role == 4): ?>
                                        Staff
                                        <?php else: ?>
                                        Account Department
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($user->created_at); ?></td>
                                    <td class="text-center">
                                        <a class="btn btn-success btn-rounded" href="<?php echo e(route('admin_account_edit',$user->id)); ?>"> Edit</a>
                                        <a class="btn btn-danger btn-rounded" href="<?php echo e(route('admin_account_delete',$user->id)); ?>"> Delete</a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div><!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/hometown/client.hometownsecurity.com.au/resources/views/admin/account.blade.php ENDPATH**/ ?>