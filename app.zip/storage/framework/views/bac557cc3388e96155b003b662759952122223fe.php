
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Invoice | Hyper - Responsive Bootstrap 4 department Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured department theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/css/app-modern.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />
        <link href="<?php echo e(asset('assets/css/app-modern-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style" />
        <link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />


    </head>

    <body class="loading" data-layout="detached" data-layout-config='{"leftSidebarCondensed":false,"darkMode":false, "showRightSidebarOnStart": true}'>
        
        <div class="navbar-custom topnav-navbar topnav-navbar-dark">
            <div class="container-fluid">

                <!-- LOGO -->
                <a href="index.html" class="topnav-logo">
                    <span class="topnav-logo-lg">
                        <img src="<?php echo e(asset('assets/images/logo1.png')); ?>" alt="" height="60">
                    </span>
                    <span class="topnav-logo-sm">
                        <img src="<?php echo e(asset('assets/images/logo_sm.png')); ?>" alt="" height="16">
                    </span>
                </a>

                <ul class="list-unstyled topbar-right-menu float-right mb-0">

                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" id="topbar-notifydrop" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="dripicons-bell noti-icon"></i>
                            <?php if(count($notifications) > 0): ?>
                            <span class="noti-icon-badge"></span>
                            <?php endif; ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-lg" aria-labelledby="topbar-notifydrop">
    
                            <!-- item-->
                            <div class="dropdown-item noti-title">
                                <h5 class="m-0">
                                    Notification
                                </h5>
                            </div>
    
                            <div style="max-height: 230px;" data-simplebar>



                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- item-->
                                <a href="<?php echo e(route('notification',$notification->id)); ?>" class="dropdown-item notify-item">
                                    <div class="notify-icon bg-primary">
                                        <i class="mdi mdi-comment-account-outline"></i>
                                    </div>
                                    <p class="notify-details"><?php echo e($notification->content); ?>

                                        <small class="text-muted"><?php echo e($notification->created_at); ?></small>
                                    </p>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                                
                            </div>
    
                            <!-- All-->
                            <a href="javascript:void(0);" class="dropdown-item text-center text-primary notify-item notify-all">
                            </a>
    
                        </div>
                    </li>
                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle nav-user arrow-none mr-0" data-toggle="dropdown" id="topbar-userdrop" href="#" role="button" aria-haspopup="true"
                            aria-expanded="false">
                            <span class="account-user-avatar"> 
                                <?php if(is_null(auth()->user()->avatar)): ?>
                                <img src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>" alt="user-image" class="rounded-circle">
                                <?php else: ?>
                                 <img src="<?php echo e(asset(auth()->user()->avatar)); ?>" alt="user-image" class="rounded-circle">
                                <?php endif; ?>
                            </span>
                            <span>
                                <span class="account-user-name"><?php echo e(auth()->user()->name); ?></span>
                                <span class="account-position"><?php echo e(auth()->user()->email); ?></span>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu profile-dropdown" aria-labelledby="topbar-userdrop">
                            
    
                            <!-- item-->
                            <a href="<?php echo e(route('profile')); ?>" class="dropdown-item notify-item">
                                <i class="mdi mdi-lock-outline mr-1"></i>
                                <span>Profile</span>
                            </a>
    
                            <!-- item-->
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item notify-item">
                                <i class="mdi mdi-logout mr-1"></i>
                                <span>Logout</span>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>

                </ul>
                <a class="button-menu-mobile disable-btn">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
            </div>
        </div>
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->
                <div class="left-side-menu left-side-menu-detached">
                    <div class="leftbar-user">
                        <a href="javascript: void(0);">
                        <img src="<?php echo e(asset('assets/images/logo1.png')); ?>" alt="" height="60">
                            <span class="leftbar-user-name">HOMETOWN</span>
                        </a>
                    </div>
                    <!--- Sidemenu -->
                    <ul class="metismenu side-nav">
                        <li class="side-nav-item">
                            <a href="<?php echo e(route('department')); ?>" class="side-nav-link">
                                <i class="uil-dashboard"></i>
                                <span> Dashboard </span>
                            </a>
                        </li>
                        <li class="side-nav-item">
                            <a href="<?php echo e(route('department_account')); ?>" class="side-nav-link">
                                <i class="uil-users-alt"></i>
                                <span> Users </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="<?php echo e(route('department_client')); ?>" class="side-nav-link">
                                <i class="uil-life-ring"></i>
                                <span> Clients </span>
                            </a>
                        </li>
                        
                        <li class="side-nav-item">
                            <a href="<?php echo e(route('department_report')); ?>" class="side-nav-link">
                                <i class="uil-document"></i>
                                <span> Reports </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="<?php echo e(route('alarm_system')); ?>" class="side-nav-link">
                                <i class="uil-sitemap"></i>
                                <span> Alarms </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="<?php echo e(route('message_inbox')); ?>" class="side-nav-link">
                                <i class="uil-envelope-heart"></i>
                                <span> Messages </span>
                            </a>
                        </li>
            
                    </ul>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>
                    <!-- Sidebar -left -->

                </div>
                <!-- Left Sidebar End -->

                <div class="content-page">
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- End Content -->

                    <!-- Footer Start -->
                    <footer class="footer">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6">
                                    2018 - 2020 © Hyper - Coderthemes.com
                                </div>
                                <div class="col-md-6">
                                    <div class="text-md-right footer-links d-none d-md-block">
                                        <a href="javascript: void(0);">About</a>
                                        <a href="javascript: void(0);">Support</a>
                                        <a href="javascript: void(0);">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </footer>
                    <!-- end Footer -->

                </div> <!-- content-page -->

            </div> <!-- end wrapper-->
        </div>


        <!-- bundle -->
        <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap4.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
        


        <!-- Datatable Init js -->

        
    </body>
</html>
<?php /**PATH /home6/hometown/client.hometownsecurity.com.au/resources/views/layouts/department.blade.php ENDPATH**/ ?>