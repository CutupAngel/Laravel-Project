
<?php $__env->startSection('content'); ?>


<div class="content">

  <!-- start page title -->
  <div class="row">
    <div class="col-12">
      <div class="page-title-box">

        <h4 class="page-title">My Information</h4>
      </div>
    </div>
  </div>
  <!-- end page title -->

  <div class="row">
    <div class="col-12">
      <div class="app-card app-card-progress-list h-100 shadow-sm">
        <div class="app-card-body p-4">
          <h4 class="header-title mt-0 mb-3">Client Information</h4>
          <div class="row">
            <div class="col-md-4">
              <div class="text-left">
                <p class="text-muted">
                  <strong> Name : </strong>
                  <span class="ml-2"><?php echo e($client->name); ?></span>
                </p>
                <p class="text-muted">
                  <strong> Email : </strong>
                  <span class="ml-2"><?php echo e($client->email); ?></span>
                </p>
                <p class="text-muted">
                  <strong> Contact Number : </strong>
                  <span class="ml-2"><?php echo e($client->phone); ?></span>
                </p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="text-left">
                <p class="text-muted">
                  <strong> Patrols : </strong>
                  <span class="ml-2"><?php echo e($client->patrol); ?></span>
                </p>
                <p class="text-muted">
                  <strong> Days : </strong>
                  <span class="ml-2"><?php echo e($client->days); ?> Days</span>
                </p>
                <p class="text-muted">
                  <strong> Lock Up : </strong>
                  <?php if($client->invoice_period == 0): ?>
                  <span class="ml-2">Yes</span>
                  <?php else: ?>
                  <span class="ml-2">No</span>
                  <?php endif; ?>
                </p>
                <p class="text-muted">
                  <strong> Contract Length : </strong>
                  <span class="ml-2"><?php echo e($client->contract_length); ?></span>
                </p>
                <p class="text-muted">
                  <strong> Site Name : </strong>
                  <span class="ml-2"><?php echo e($client->site_name); ?></span>
                </p>
                <p class="text-muted">
                  <strong> Call Out Fee : </strong>
                  <span class="ml-2"><?php echo e($client->call_out); ?></span>
                </p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="text-left">
                <p class="text-muted">
                  <strong> Payments : </strong>
                  <span class="ml-2"><?php echo e($client->payment); ?></span>
                </p>
                <p class="text-muted">
                  <strong> Payment Terms : </strong>
                  <span class="ml-2"><?php echo e($client->payment_term); ?> Days</span>
                </p>
                <p class="text-muted">
                  <strong> Invoice Period : </strong>
                  <?php if($client->invoice_period == 0): ?>
                  <span class="ml-2">End of Month</span>
                  <?php else: ?>
                  <span class="ml-2">Start of Month</span>
                  <?php endif; ?>
                </p>
              </div>
            </div>
          </div>


        </div><!-- end card-body-->
      </div> <!-- end card-->
    </div> <!-- end col -->
  </div>


  <div class="row">
    <div class="col-md-12">
      <div class="app-card app-card-progress-list h-100 shadow-sm">
        <div class="app-card-body p-4">

          <!-- Invoice Logo-->
          <table id="basic-datatable" class="table dt-responsive nowrap w-100">
            <thead>
              <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(asset($report->path)); ?>" target="_new"> <?php echo e($report->title); ?></a></td>
                <td><?php echo e($report->created_at); ?></td>
                <td class="text-center">


                  <a class="btn btn-danger btn-rounded" href="<?php echo e(route('delete_report',$report->id)); ?>"> Delete</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- end row-->

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/hometown/login.hometownsecurity.com.au/resources/views/client/index.blade.php ENDPATH**/ ?>