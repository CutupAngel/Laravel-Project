
<?php $__env->startSection('content'); ?>


<div class="content">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
               
                <h4 class="page-title">Reports</h4>
               
            </div>
         
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Client</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(asset('$report->path')); ?>"><?php echo e($report->title); ?></a></td>
                                <td><a href="<?php echo e(route('admin_client_show',$report->client_id)); ?>"><?php echo e($report->user_name); ?></a></td>
                                <td><?php echo e($report->created_at); ?></td>
                               
                                <td class="text-center">
                                    <a class="btn btn-danger btn-rounded" href="<?php echo e(route('admin_delete_report',$report->id)); ?>"> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div><!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2021\June\Client\ClientManage\resources\views/staff/report.blade.php ENDPATH**/ ?>