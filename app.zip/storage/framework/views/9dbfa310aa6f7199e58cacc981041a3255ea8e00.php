
<?php $__env->startSection('content'); ?>


<div class="content">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                
                <h4 class="page-title">Clients</h4>
               
            </div>
         
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-sm-4">
                            <a href="<?php echo e(route('department_client_create')); ?>" class="btn btn-primary mb-2">Create Client</a>
                        </div>
                    </div>
                   
                    <!-- Invoice Logo-->
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->email); ?></td>
                                <td><?php echo e($client->phone); ?></td>
                                <td><?php echo e($client->created_at); ?></td>
                                <td class="text-center">
                                    <a class="btn btn-info btn-rounded" href="<?php echo e(route('department_client_show',$client->id)); ?>"> Show</a>
                                    <a class="btn btn-success btn-rounded" href="<?php echo e(route('department_client_edit',$client->id)); ?>"> Edit</a>
                                    <a class="btn btn-danger btn-rounded" href="<?php echo e(route('department_client_delete',$client->id)); ?>"> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div><!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.department', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/hometown/client.hometownsecurity.com.au/resources/views/department/client.blade.php ENDPATH**/ ?>