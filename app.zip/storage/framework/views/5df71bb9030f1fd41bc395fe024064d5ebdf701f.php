
<?php $__env->startSection('content'); ?>
<div class="content">
                        
    <!-- start page email-title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                
                <h4 class="page-title">Email Show</h4>
            </div>
        </div>
    </div>     
    <!-- end page email-title --> 
    
    <div class="row">

        <!-- Right Sidebar -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <!-- Left sidebar -->
                    <div class="page-aside-left">

                        <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#compose-modal">Compose</button>

                        <div class="email-menu-list mt-3">
                            <a href="<?php echo e(route('message_inbox')); ?>"><i class="dripicons-inbox mr-2"></i>Inbox</a>
                            <a href="<?php echo e(route('message_sent')); ?>" ><i class="dripicons-exit mr-2"></i>Sent Mail</a>
                        </div>
                    </div>
                    <!-- End Left sidebar -->

                    <div class="page-aside-right">
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-3">
                            <h5 class="font-18"><?php echo e($message->subject); ?></h5>

                            <hr/>

                            <div class="media mb-3 mt-1">
                                <div class="media-body">
                                    <small class="float-right"><?php echo e($message->created_at); ?></small>
                                    <small class="text-muted">From: <?php echo e($message->from_name); ?></small>
                                    <small class="text-muted">To: <?php echo e($message->to_name); ?></small>
                                </div>
                            </div>

                            <p><?php echo e($message->content); ?></p>
                            <p class="text-right"><button type="button" style="width:150px" class="btn btn-default btn-block" onclick="onReply('<?php echo e($message->from_name); ?>','<?php echo e($message->id_from); ?>')">Reply</button></p>
                            <hr/>


                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- end .mt-4 -->

                                        </div>
                    <!-- end inbox-rightbar-->
                    </div>
                <!-- end card-body -->
                <div class="clearfix"></div>
            </div> <!-- end card-box -->

        </div> <!-- end Col -->
    </div><!-- End row -->
    <!-- Compose Modal -->
        <div id="reply-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="compose-header-modalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-colored-header bg-primary">
                    <h4 class="modal-title" id="compose-header-modalLabel">New Message</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-3">
                    <form class="p-1" method="post" action="<?php echo e(route('message_send')); ?>">
                    <?php echo csrf_field(); ?>
                        <div class="form-group mb-2">
                            <label for="msgto" id="msgto"></label>
                            <input type="hidden" name="id" id="idto" />
                        </div>
                        <div class="form-group mb-2">
                            <label for="mailsubject">Subject</label>
                            <input type="text"  required name="subject" class="form-control" placeholder="your subject">
                        </div>
                        <div class="form-group write-mdg-box mb-3">
                           
                            <textarea  name="content" required style="width: -webkit-fill-available;"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary"><i class="mdi mdi-send mr-1"></i> Send Message</button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    
</div>
<script>
    function onReply(name,id){
        $('#idto').val(id);
        $('#msgto').text(name);
        $('#reply-modal').modal();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/hometown/client.hometownsecurity.com.au/resources/views/admin/message_show.blade.php ENDPATH**/ ?>