
<?php $__env->startSection('content'); ?>


<div class="content">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right"><a href="<?php echo e(route('admin_client')); ?>" class="btn btn-primary">Back</a></div>
                <h4 class="page-title">Create Client</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('admin_client_store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="simpleinput">Name</label>
                                    <input type="text" id="simpleinput" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required >
                                </div>

                                <div class="form-group">
                                    <label for="example-email">Contact Email</label>
                                    <input type="email" id="example-email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="simpleinput">Contact Number</label>
                                    <input type="text" id="simpleinput" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required >
                                </div>

                                <div class="form-group">
                                    <label for="password"> Password</label>
                                    <div class="input-group input-group-merge">
                                        <input type="password" id="password" class="form-control" name="password" placeholder="Enter your password">
                                        <div class="input-group-append" data-password="false">
                                            <div class="input-group-text">
                                                <span class="password-eye"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-date">Payments</label>
                                    <input type="text" id="simpleinput" class="form-control <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="payment" value="<?php echo e(old('payment')); ?>" required >
                                </div>

                                <div class="form-group">
                                    <label for="example-select">Payment Terms</label>
                                    <select class="form-control" name="payment_term" id="example-select">
                                        <option selected value="7">7 Days</option>
                                        <option value="15">14 Days</option>
                                        <option value="30">30 Days</option>
                                        <option value="45">45 Days</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="example-select">Invoice Period</label>
                                    <select class="form-control" name="invoice_period" id="example-select">
                                        <option selected value="0">End of Month</option>
                                        <option value="1">Start of Month</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="example-fileinput">Avatar</label>
                                    <input type="file" id="example-fileinput" name="avatar" class="form-control-file" require>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="simpleinput">Patrols</label>
                                    <input type="number" id="simpleinput" class="form-control <?php $__errorArgs = ['patrol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="patrol" value="<?php echo e(old('patrol')); ?>" required >
                                </div>

                                <div class="form-group">
                                    <label for="simpleinput">Days</label>
                                    <input type="number" id="simpleinput" class="form-control <?php $__errorArgs = ['days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="days" value="<?php echo e(old('days')); ?>" required >
                                </div>

                                <div class="form-group">
                                    <label for="example-select">Lock Up</label>
                                    <select class="form-control" name="lock_up" id="example-select">
                                        <option selected value="0">Yes</option>
                                        <option value="1">No</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="example-select">Contract Length</label>
                                    <select class="form-control" name="contract_length" id="example-select">
                                        <option selected value="1">1 Month</option>
                                        <option value="3">3 Month</option>
                                        <option value="6">6 Month</option>
                                        <option value="12">12 Month</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="example-date">Site Name</label>
                                    <input type="text" id="simpleinput" class="form-control <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="site_name" value="<?php echo e(old('site_name')); ?>" required >
                                </div>

                                <div class="form-group">
                                    <label for="example-date">Call Out Fee</label>
                                    <input type="text" id="simpleinput" class="form-control <?php $__errorArgs = ['call_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="call_out" value="<?php echo e(old('call_out')); ?>" required >
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-0">
                            <button class="btn btn-primary" type="submit">Create Client</button>
                        </div>
                    </form>
                </div><!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2021\June\Client\ClientManage\resources\views/admin/client_create.blade.php ENDPATH**/ ?>