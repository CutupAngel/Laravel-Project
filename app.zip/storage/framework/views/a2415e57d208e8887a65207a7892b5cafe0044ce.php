<?php $__env->startSection('content'); ?>

<div class="row g-0 app-auth-wrapper">
  <div class="col-12 col-md-7 col-lg-6 auth-main-col text-center p-5">
    <div class="d-flex flex-column align-content-end">
      <div class="app-auth-body mx-auto">
        <div class="app-auth-branding mb-4">
          <a class="app-logo" href="<?php echo e(route('password.request')); ?>">
            <img class="logo-icon me-2" src="<?php echo e(asset('assets/images/logo1.png')); ?>" alt="logo">
          </a>
        </div>
        <h2 class="auth-heading text-center mb-4"><?php echo e(__('Reset Password')); ?></h2>

        <div class="auth-intro mb-4 text-center">
          Enter your email address below. We'll email you a link to a page where you can easily create a new password.
        </div>

        <div class="app-card-body p-4">
          <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

          </div>
          <?php endif; ?>
          <div class="auth-form-container text-left">
            <form class="auth-form resetpass-form" method="POST" action="<?php echo e(route('password.email')); ?>">
              <?php echo csrf_field(); ?>

              <div class="email mb-3">
                <label for="email" class="col-md-4 col-form-label text-md-right" placeholder="Your Email" required="required"><?php echo e(__('E-Mail Address')); ?></label>

                <div class="">
                  <input id="email" type="email" class="form-control login-email <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="">
                <button type="submit" class="btn app-btn-primary btn-block theme-btn mx-auto">
                  <?php echo e(__('Reset Password')); ?>

                </button>
              </div>
            </form>
            <div class="auth-option text-center pt-5">
              <a class="app-link" href="<?php echo e(route('login')); ?>">Log in</a>
              <!-- <span class="px-2">|</span> -->
              <!-- <a class="app-link" href="login.html">Sign up</a> -->
            </div>
          </div>
          <!--//auth-form-container-->


        </div>
        <!--//auth-body-->

        <footer class="app-auth-footer">
          <div class="container text-center py-3">
            <small class="copyright">
              Copyright 2021 | HomeTownSecurity | All rights reserved.
            </small>
          </div>
        </footer>
        <!--//app-auth-footer-->
      </div>
      <!--//flex-column-->
    </div>
  </div>
  <!--//auth-main-col-->
  <div class="col-12 col-md-5 col-lg-6 h-100 auth-background-col">
    <div class="auth-background-holder">
    </div>
    <div class="auth-background-mask"></div>
    <div class="auth-background-overlay p-3 p-lg-5">
      <div class="d-flex flex-column align-content-end h-100">
        <div class="h-100"></div>
        <div class="overlay-content p-3 p-lg-4 rounded">
          <blockquote>
            “With faith, discipline and selfless devotion to duty, there is nothing worthwhile that you cannot achieve.”
          </blockquote>
          <h5 class="mb-3 overlay-title">~ Muhammad Ali Jinnah</h5>
        </div>
      </div>
    </div>
    <!--//auth-background-overlay-->
  </div>
  <!--//auth-background-col-->
  <!--//row-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OnGoing Projects\hometownsecurity-backup\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>