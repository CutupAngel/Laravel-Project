<?php echo e($slot); ?>

<?php /**PATH /home6/hometown/client.hometownsecurity.com.au/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>