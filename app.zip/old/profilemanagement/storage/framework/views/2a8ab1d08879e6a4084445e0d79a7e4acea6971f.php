<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="page-content">
      <div>
<div class="profile-page">
  <div class="wrapper">
    <div class="page-header page-header-small" filter-color="green">
      <style>
       .page-header .page-header-image{

        background-image:url('<?php echo e($user->image); ?>');
                 }
                 </style>
      <div class="page-header-image" data-parallax="true"  ></div>
      <div class="container">
        <div class="content-center">
          <div class="cc-profile-image"><a ><img src="<?php echo e($user->image); ?>" alt="Image"/></a></div>
          <div class="h2 title"><?php echo e($user->name); ?></div>
        <p class="category text-white"><?php echo e($user->position); ?></p>
        <?php if(Auth::user()->role == 'admin'): ?>
            <a class="btn btn-primary smooth-scroll mr-2" href="#contact" data-aos="zoom-in" data-toggle="modal" data-target="#editform" data-aos-anchor="data-aos-anchor">Edit Contract</a><a class="btn btn-warning" href="#" data-aos="zoom-in" data-toggle="modal" data-target="#addnote" data-aos-anchor="data-aos-anchor">Add Note</a>
            <a class="btn btn-info smooth-scroll mr-2" href="#contact" data-aos="zoom-in" data-toggle="modal" data-target="#addreport" data-aos-anchor="data-aos-anchor">Add Report</a><a class="btn btn-danger" data-toggle="modal" data-target="#exampleModal" data-aos="zoom-in" data-aos-anchor="data-aos-anchor">Delete Contract</a>

            <?php else: ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('inbox'),'active' => request()->routeIs('inbox')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('inbox')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('inbox'))]); ?>
                        Messages 


                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>

          </div>
      </div>
      <div class="section">
        <div class="container">
          <!-- <div class="button-container"><a class="btn btn-default btn-round btn-lg btn-icon" href="#" rel="tooltip" title="Follow me on Facebook"><i class="fa fa-facebook"></i></a><a class="btn btn-default btn-round btn-lg btn-icon" href="#" rel="tooltip" title="Follow me on Twitter"><i class="fa fa-twitter"></i></a><a class="btn btn-default btn-round btn-lg btn-icon" href="#" rel="tooltip" title="Follow me on Google+"><i class="fa fa-google-plus"></i></a><a class="btn btn-default btn-round btn-lg btn-icon" href="#" rel="tooltip" title="Follow me on Instagram"><i class="fa fa-instagram"></i></a></div> -->
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section" id="about">
  <div class="container">
    <div class="card" data-aos="fade-up" data-aos-offset="10">
      <div class="row">
        <div class="col-lg-6 col-md-12">
          <div class="card-body">
            <div class="h4 mt-0 title">Basic Information</div>
            <div class="row">
              <div class="col-sm-6"><strong class="text-uppercase">Client Status :</strong></div>
              <div class="col-sm-6 active"><?php if($user->status == 1): ?>
                Active
              <?php elseif($user->status == 0 ): ?>
                <div class="text-danger">Inactive</div>
              <?php else: ?>
                Unknown
              <?php endif; ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Contract Term:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->cterm); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Price Per Check:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->price); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Contract Start Date:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->startdate); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Client Address:</strong></div>
              <div class="col-sm-6"><?php echo e($user->address); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Client Email:</strong></div>
              <div class="col-sm-6"><?php echo e($user->email); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Contract Name:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->ahname); ?></div>
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-12">
          <div class="card-body">
            <div class="h4 mt-0 title"></br></div>
           
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Contract Position:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->position); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Approach :</strong></div>
              <div class="col-sm-6"><?php echo e($contract->approach); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Payment Terms:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->paymentterms); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Afterhours Contract Name:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->ahname); ?></div>
            </div>
            <div class="row mt-3">
              <div class="col-sm-6"><strong class="text-uppercase">Afterhours Contract Number:</strong></div>
              <div class="col-sm-6"><?php echo e($contract->ahnumber); ?></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- <div class="section" id="skill">
  <div class="container">
    <div class="h4 text-center mb-4 title">Professional Skills</div>
    <div class="card" data-aos="fade-up" data-aos-anchor-placement="top-bottom">
      <div class="card-body">
        <div class="row">
          <div class="col-md-6">
            <div class="progress-container progress-primary"><span class="progress-badge">HTML</span>
              <div class="progress">
                <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 80%;"></div><span class="progress-value">80%</span>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="progress-container progress-primary"><span class="progress-badge">CSS</span>
              <div class="progress">
                <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 75%;"></div><span class="progress-value">75%</span>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="progress-container progress-primary"><span class="progress-badge">JavaScript</span>
              <div class="progress">
                <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div><span class="progress-value">60%</span>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="progress-container progress-primary"><span class="progress-badge">SASS</span>
              <div class="progress">
                <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div><span class="progress-value">60%</span>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="progress-container progress-primary"><span class="progress-badge">Bootstrap</span>
              <div class="progress">
                <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 75%;"></div><span class="progress-value">75%</span>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="progress-container progress-primary"><span class="progress-badge">Photoshop</span>
              <div class="progress">
                <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 70%;"></div><span class="progress-value">70%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> -->
<!-- <div class="section" id="portfolio">
  <div class="container">
    <div class="row">
      <div class="col-md-6 ml-auto mr-auto">
        <div class="h4 text-center mb-4 title">Portfolio</div>
        <div class="nav-align-center">
          <ul class="nav nav-pills nav-pills-primary" role="tablist">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#web-development" role="tablist"><i class="fa fa-laptop" aria-hidden="true"></i></a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#graphic-design" role="tablist"><i class="fa fa-picture-o" aria-hidden="true"></i></a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Photography" role="tablist"><i class="fa fa-camera" aria-hidden="true"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="tab-content gallery mt-5">
      <div class="tab-pane active" id="web-development">
        <div class="ml-auto mr-auto">
          <div class="row">
            <div class="col-md-6">
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#web-development">
                  <figure class="cc-effect"><img src="images/project-1.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Recent Project</div>
                      <p>Web Development</p>
                    </figcaption>
                  </figure></a></div>
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#web-development">
                  <figure class="cc-effect"><img src="images/project-2.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Startup Project</div>
                      <p>Web Development</p>
                    </figcaption>
                  </figure></a></div>
            </div>
            <div class="col-md-6">
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#web-development">
                  <figure class="cc-effect"><img src="images/project-3.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Food Order Project</div>
                      <p>Web Development</p>
                    </figcaption>
                  </figure></a></div>
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#web-development">
                  <figure class="cc-effect"><img src="images/project-4.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Web Advertising Project</div>
                      <p>Web Development</p>
                    </figcaption>
                  </figure></a></div>
            </div>
          </div>
        </div>
      </div>
      <div class="tab-pane" id="graphic-design" role="tabpanel">
        <div class="ml-auto mr-auto">
          <div class="row">
            <div class="col-md-6">
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#graphic-design">
                  <figure class="cc-effect"><img src="images/graphic-design-1.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Triangle Pattern</div>
                      <p>Graphic Design</p>
                    </figcaption>
                  </figure></a></div>
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#graphic-design">
                  <figure class="cc-effect"><img src="images/graphic-design-2.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Abstract Umbrella</div>
                      <p>Graphic Design</p>
                    </figcaption>
                  </figure></a></div>
            </div>
            <div class="col-md-6">
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#graphic-design">
                  <figure class="cc-effect"><img src="images/graphic-design-3.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Cube Surface Texture</div>
                      <p>Graphic Design</p>
                    </figcaption>
                  </figure></a></div>
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#graphic-design">
                  <figure class="cc-effect"><img src="images/graphic-design-4.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Abstract Line</div>
                      <p>Graphic Design</p>
                    </figcaption>
                  </figure></a></div>
            </div>
          </div>
        </div>
      </div> -->
      <!-- <div class="tab-pane" id="Photography" role="tabpanel">
        <div class="ml-auto mr-auto">
          <div class="row">
            <div class="col-md-6">
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#Photography">
                  <figure class="cc-effect"><img src="images/photography-1.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Photoshoot</div>
                      <p>Photography</p>
                    </figcaption>
                  </figure></a></div>
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#Photography">
                  <figure class="cc-effect"><img src="images/photography-3.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Wedding Photoshoot</div>
                      <p>Photography</p>
                    </figcaption>
                  </figure></a></div>
            </div>
            <div class="col-md-6">
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#Photography">
                  <figure class="cc-effect"><img src="images/photography-2.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Beach Photoshoot</div>
                      <p>Photography</p>
                    </figcaption>
                  </figure></a></div>
              <div class="cc-porfolio-image img-raised" data-aos="fade-up" data-aos-anchor-placement="top-bottom"><a href="#Photography">
                  <figure class="cc-effect"><img src="images/photography-4.jpg" alt="Image"/>
                    <figcaption>
                      <div class="h4">Nature Photoshoot</div>
                      <p>Photography</p>
                    </figcaption>
                  </figure></a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> -->
<div class="section" id="experience">
  <div class="container cc-experience">
    <div class="h4 text-center mb-4 title">Notes</div>
    <div class="activity-feed">
      <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card">
        <div class="card-body">

        
      <div class="feed-item">
        <div class="date"><?php echo e($note->date); ?></div>
        <div class="text"><?php echo e($note->note); ?></div>
      </div>
    </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
       

</div>


<!-- 
<div class="raw position-relative justify-content-center col-auto">

<div class=" table-responsive" id="">
  <div class="container  justify-content-center ">
</br>
    <div class="h4  col-auto text-center mb-4 title">Weekly Reports</div>
   
    
  <table class="  table justify-content-center table-hover able-responsive ">
    <thead>
        <tr>
        
            <th>ID</th>
            <th>Name</th>
           
            <th>File</th>
           
        </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
         
            <td><?php echo e($report->id); ?></td>
            <td><?php echo e($report->name); ?></td>
            
            <td> <a class="btn btn-primary smooth-scroll mr-2" href="<?php echo e($report->path); ?>" data-aos="zoom-in" data-aos-anchor="data-aos-anchor">View Report</a></td>
           
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
    </tbody>
</table>

</div>

</div>


<div class="raw position-relative justify-content-center col-auto">

<div class=" table-responsive" id="">
  <div class="container  justify-content-center ">
</br>
    <div class="h4  col-auto text-center mb-4 title">Monthly Reports</div>
   
    
  <table class="  table justify-content-center table-hover able-responsive ">
    <thead>
        <tr>
        
            <th>ID</th>
            <th>Name</th>
           
            <th>File</th>
           
        </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $monthlyreports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
         
            <td><?php echo e($report->id); ?></td>
            <td><?php echo e($report->name); ?></td>
            
            <td> <a class="btn btn-primary smooth-scroll mr-2" href="<?php echo e($report->path); ?>" data-aos="zoom-in" data-aos-anchor="data-aos-anchor">View Report</a></td>
           
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
    </tbody>
</table>

</div>

</div> -->

<div class="container mt-5 mb-5"> <br><br>
<div class="h4  col-auto text-center mb-4 title">Weekly Reports</div>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>File</th>
                
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($report->id); ?></td>
            <td><?php echo e($report->name); ?></td>
            
            <td class="text-right"> <a class="btn btn-primary smooth-scroll mr-2" href="<?php echo e($report->path); ?>" data-aos="zoom-in" data-aos-anchor="data-aos-anchor">View Report</a></td>
               
            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      
    </table>
    <br> <br> <br> <br>
    </div>

  
<div class="container mt-5 mb-5">
 
<div class="h4  col-auto text-center mb-4 title">Monthly Reports</div>
<table id="example2" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>File</th>
                
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $monthlyreports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($report->id); ?></td>
            <td><?php echo e($report->name); ?></td>
            
            <td class="text-right"> <a class="btn btn-primary smooth-scroll mr-2" href="<?php echo e($report->path); ?>" data-aos="zoom-in" data-aos-anchor="data-aos-anchor">View Report</a></td>
               
            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      
    </table>
    <br> <br> <br> <br>
    </div>
<!-- <div class="section" id="reference">
  <div class="container cc-reference">
    <div class="h4 mb-4 text-center title">References</div>
    <div class="card" data-aos="zoom-in">
      <div class="carousel slide" id="cc-Indicators" data-ride="carousel">
        <ol class="carousel-indicators">
          <li class="active" data-target="#cc-Indicators" data-slide-to="0"></li>
          <li data-target="#cc-Indicators" data-slide-to="1"></li>
          <li data-target="#cc-Indicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="row">
              <div class="col-lg-2 col-md-3 cc-reference-header"><img src="images/reference-image-1.jpg" alt="Image"/>
                <div class="h5 pt-2">Aiyana</div>
                <p class="category">CEO / WEBM</p>
              </div>
              <div class="col-lg-10 col-md-9">
                <p> Habitasse venenatis commodo tempor eleifend arcu sociis sollicitudin ante pulvinar ad, est porta cras erat ullamcorper volutpat metus duis platea convallis, tortor primis ac quisque etiam luctus nisl nullam fames. Ligula purus suscipit tempus nascetur curabitur donec nam ullamcorper, laoreet nullam mauris dui aptent facilisis neque elementum ac, risus semper felis parturient fringilla rhoncus eleifend.</p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="row">
              <div class="col-lg-2 col-md-3 cc-reference-header"><img src="images/reference-image-2.jpg" alt="Image"/>
                <div class="h5 pt-2">Braiden</div>
                <p class="category">CEO / Creativem</p>
              </div>
              <div class="col-lg-10 col-md-9">
                <p> Habitasse venenatis commodo tempor eleifend arcu sociis sollicitudin ante pulvinar ad, est porta cras erat ullamcorper volutpat metus duis platea convallis, tortor primis ac quisque etiam luctus nisl nullam fames. Ligula purus suscipit tempus nascetur curabitur donec nam ullamcorper, laoreet nullam mauris dui aptent facilisis neque elementum ac, risus semper felis parturient fringilla rhoncus eleifend.</p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="row">
              <div class="col-lg-2 col-md-3 cc-reference-header"><img src="images/reference-image-3.jpg" alt="Image"/>
                <div class="h5 pt-2">Alexander</div>
                <p class="category">CEO / Webnote</p>
              </div>
              <div class="col-lg-10 col-md-9">
                <p> Habitasse venenatis commodo tempor eleifend arcu sociis sollicitudin ante pulvinar ad, est porta cras erat ullamcorper volutpat metus duis platea convallis, tortor primis ac quisque etiam luctus nisl nullam fames. Ligula purus suscipit tempus nascetur curabitur donec nam ullamcorper, laoreet nullam mauris dui aptent facilisis neque elementum ac, risus semper felis parturient fringilla rhoncus eleifend.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> -->
<!-- <div class="section" id="contact">
  <div class="cc-contact-information" style="background-color: rgb(16, 110, 16)">
    <div class="container">
      <div class="cc-contact">
        <div class="row">
          <div class="col-md-9">
            <div class="card mb-0" data-aos="zoom-in">
              <div class="h4 text-center title">Message</div>
              <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6 ">
                  <div class="card-body text-center">
                    <form action="https://formspree.io/your@email.com" method="POST">
                      <div class="p pb-3"><strong>Type Your Message Here </strong></div> -->
                      <!-- <div class="row mb-3">
                        <div class="col">
                          <div class="input-group"><span class="input-group-addon"><i class="fa fa-user-circle"></i></span>
                            <input class="form-control" type="text" name="name" placeholder="Name" required="required"/>
                          </div>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col">
                          <div class="input-group"><span class="input-group-addon"><i class="fa fa-file-text"></i></span>
                            <input class="form-control" type="text" name="Subject" placeholder="Subject" required="required"/>
                          </div>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col">
                          <div class="input-group"><span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" type="email" name="_replyto" placeholder="E-mail" required="required"/>
                          </div>
                        </div>
                      </div> -->
                      <!-- <div class="row mb-3">
                        <div class="col">
                          <div class="form-group">
                            <textarea class="form-control" name="message" placeholder="Your Message" required="required"></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col">
                          <button class="btn btn-primary" type="submit">Send</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div> -->
                <!-- <div class="col-md-6">
                  <div class="card-body">
                    <p class="mb-0"><strong>Address </strong></p>
                    <p class="pb-2">140, City Center, New York, U.S.A</p>
                    <p class="mb-0"><strong>Phone</strong></p>
                    <p class="pb-2">+1718-111-0011</p>
                    <p class="mb-0"><strong>Email</strong></p>
                    <p>anthony@company.com</p>
                  </div>
                </div> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></div>
    </div>
    <!-- <footer class="footer">
      <div class="container text-center"><a class="cc-facebook btn btn-link" href="#"><i class="fa fa-facebook fa-2x " aria-hidden="true"></i></a><a class="cc-twitter btn btn-link " href="#"><i class="fa fa-twitter fa-2x " aria-hidden="true"></i></a><a class="cc-google-plus btn btn-link" href="#"><i class="fa fa-google-plus fa-2x" aria-hidden="true"></i></a><a class="cc-instagram btn btn-link" href="#"><i class="fa fa-instagram fa-2x " aria-hidden="true"></i></a></div>
      <div class="h4 title text-center">Anthony Barnett</div>
      <div class="text-center text-muted">
        <p>&copy; Creative CV. All rights reserved.<br>Design - <a class="credit" href="https://templateflip.com" target="_blank">TemplateFlip</a></p>
      </div>
    </footer> -->


<!-- model -->
<!-- Modal delete -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to delete this client ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a type="button" href="<?php echo e(URL::to('contract/' . $contract->id . '/delete')); ?>" class="btn btn-primary">Delete</a>
      </div>
    </div>
  </div>
</div>

<!-- Modal edit -->
<div class="modal mod fade bd-example-modal-lg" id="editform" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="#editform" aria-label="Close">
        </button>
      </div>
      <div class="modal-body">
        

      <form method="POST" action="<?php echo e(URL::to('contract/' . $contract->id . '/edit')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            
 
<div class="justify-content-between text-center align-items-center  mt-1 col-md-12">
                     <h2 class="text-center"> Edit Contract of <?php echo e($user->name); ?> </h2>
                     <div class="cc-profile-image"><a ><img src="<?php echo e($user->image); ?>" alt="Image"/></a></div>
                </div>

<div class="container rounded bg-white ">

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-1','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-1','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

  <div class="row align-items-center">
                
      <div class="col-md-12 border-right">
          <div class="p-3 py-5">

              <div class="row mt-2">
                 
                  <div class="col-md-6"><label class="labels">CONTRACT TERM</label><input type="text"  name="cterm" class="form-control" value="<?php echo e($contract->cterm); ?>" placeholder="CONTRACT TERM"></div>
                  <div class="col-md-6"><label class="labels">PRICE PER CHECK</label><input type="text"  name="price" class="form-control" placeholder="" value="<?php echo e($contract->price); ?>"></div>
              </div>
              <div class="row mt-3">
                 
                  <div class="col-md-6"><label class="labels">CONTRACT START DATE</label><input type="text"  name="startdate" class="form-control" placeholder="CONTRACT START DATE" value="<?php echo e($contract->startdate); ?>"></div>
                  <!-- <div class="col-md-6"><label class="labels">CLIENT ADDRESS</label><input type="text"  name="address" class="form-control" placeholder="CLIENT ADDRESS" value=""></div> -->
                  <!-- <div class="col-md-6"><label class="labels">CLIENT EMAIL</label><input type="text"  name="email" class="form-control" placeholder="CLIENT EMAIL" value=""></div> -->
                  <div class="col-md-6"><label class="labels">CONTACT NAME</label><input type="text" name="name" class="form-control" placeholder="CONTRACT NAME" value="<?php echo e($contract->cname); ?>"></div>
                  <div class="col-md-6"><label class="labels">CONTACT POSITION</label><input type="text" name="position" class="form-control" placeholder="CONTRACT POSITION" value="<?php echo e($contract->position); ?>"></div>
                  <div class="col-md-6"><label class="labels">APPROACH</label><input type="text" name="approach" class="form-control" placeholder="APPROACH" value="<?php echo e($contract->approach); ?>"></div>
                  <div class="col-md-4 mt-2"><label class="labels">PAYMENT TERMS</label><input type="text" name="paymentterms" class="form-control" placeholder="PAYMENT TERMS" value="<?php echo e($contract->paymentterms); ?>"></div>
                  <div class="col-md-4 mt-2"><label class="labels">AFTERHOURS CONTACT NAME</label><input type="text" name="ahname" class="form-control" placeholder="CONTRACT NAME" value="<?php echo e($contract->ahname); ?>"></div>
                  <div class="col-md-4 mt-2"><label class="labels">AFTERHOURS CONTACT NUMBER</label><input type="text" name="ahnumber" class="form-control" placeholder="CONTRACT NAME" value="<?php echo e($contract->ahnumber); ?>"></div>

              </div>
              
              <div class="row mt-3">
              <div class="col-md-4 text-right">          
</div>
              <!-- <div class="col-md-8"></br><label class="labels">Upload New Profile Image</label><input type="file" name="image" class="form-control"></div> -->
</div>
          </div>
      </div>
     
      
  </div>
  <div class="flex items-center justify-end mt-2">
               
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['type' => 'button','class' => 'btn btn-secondary','dataDismiss' => 'modal']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'button','class' => 'btn btn-secondary','data-dismiss' => 'modal']); ?>Close <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

               <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-4']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4']); ?>
                   <?php echo e(__('Add Contract')); ?>

                <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

           </div>
</div>

</div>

</div>


</form>
            





      </div>
     
    </div>
  </div>
</div>

<!-- add notes -->
<div class="modal fade" id="addnote" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Note</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="<?php echo e(URL::to('clients/' . $contract->id . '/addnote')); ?>">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Date :</label>
            <input type="date" name="date" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Note :</label>
            <textarea class="form-control" name="note" id="message-text"></textarea>
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Note</button>
        </form>
      </div>
    </div>
  </div>
</div>



<!-- add report -->
<div class="modal fade" id="addreport" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Report</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="<?php echo e(URL::to('clients/' . $contract->id . '/addreport')); ?>"  enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Name :</label>
            <input type="text" name="name" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
          <div class="form-check form-switch">
          <label class="form-check-label" for="recipient-name">Monthly Report ? &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</label>
         <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" name="monthly" value="1">
  
</div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Select File :</label>
            <input type="file" class="form-control p-1" name="report" id="message-text"></input>
          </div>
        <br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Report</button>
        </form>
      </div>
    </div>
  </div>
</div>


    
    
   
    <script src="<?php echo e(asset('js/core/popper.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/core/bootstrap.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/now-ui-kit.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/main.js?ver=1.1.0')); ?>"></script>
                     <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\client dashboard\profilemanagement\resources\views/welcome.blade.php ENDPATH**/ ?>