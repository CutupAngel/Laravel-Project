<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
       
        <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Create User Profile</h2>
                </div>

<div class="container  rounded bg-white mt-5 mb-5">

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

  <div class="row align-items-center">
                
      <div class="col-md-12 border-right">
          <div class="p-3 py-5">
             
              <div class="row mt-2">
                
                 
                  <div class="col-md-12"><label class="labels">NAME</label>
                  <input type="text"  name="name" class="form-control" value="" placeholder="CLIENT NAME"></div>
                 
                  <div class="col-md-12 mt-2"><label class="labels">EMAIL</label>
                  <input type="text" name="email" class="form-control" placeholder="CLIENT EMAIL" value=""></div>
                 
                  <div class="col-md-12 mt-2"><label class="labels">ADDRESS</label>
                  <input type="text" name="address" class="form-control" placeholder="CLIENT ADDRESS" value=""></div>
              </div>
              <br>
              <hr>

              <div class="row mt-3">
                  <div class="col-md-6"><label class="labels">PASSWORD</label><input required type="password" name="password" class="form-control" placeholder="PASSWORD" value=""></div>
                  <div class="col-md-6"><label class="labels">CONFIRM PASSWORD</label><input type="password" id="password_confirmation" name="password_confirmation" class="form-control" value="" placeholder="RE TYPE PASSWORD" required></div>
              </div>
              <hr>
              <div class="row mt-3">
              <div class="col-md-6"></div>
              <div class="col-md-6"><label class="labels">Profile Image</label><input type="file" name="image" class="form-control"></div>
</div>
          </div>
          
      </div>
     
      
  </div>

  
  <div class="flex items-center justify-end mt-4 mb-5">
               
  <div class="d-flex">
  <div class="form-check mt-2">
          <label class="form-check-label font-weight-bold  text-danger" for="recipient-name ">Make This As Admin ? &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</label>
         <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" name="admin" value="1">
  
</div>

               <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-4 mb-5']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4 mb-5']); ?>
                   <?php echo e(__('Add User')); ?>

                <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
               </div>         
           </div>
</div>

</div>

</div>


</form>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home6/hometown/client.hometownsecurity.com.au/profilemanagement/resources/views/auth/register.blade.php ENDPATH**/ ?>