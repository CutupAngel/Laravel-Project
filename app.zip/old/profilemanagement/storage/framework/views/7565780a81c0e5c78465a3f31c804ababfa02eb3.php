<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="container   mb-1 mt-5 ">
            <div class=" row">
                <div class="col-md-12 col-lg-12">
                        <div class="  text-center">
                            <h2 class="text-black ">Your Mailbox</h2>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

  
<nav>
  <div class="nav nav" id="nav-tab" role="tablist">
    <div class="d-flex">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => '   ','id' => 'nav-home-tab','dataAos' => 'zoom-in','dataToggle' => 'tab','href' => '#nav-home','role' => 'tab','ariaControls' => 'nav-home','ariaSelected' => 'true']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => '   ','id' => 'nav-home-tab','data-aos' => 'zoom-in','data-toggle' => 'tab','href' => '#nav-home','role' => 'tab','aria-controls' => 'nav-home','aria-selected' => 'true']); ?>In box <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => ' ml-2 ','id' => 'nav-profile-tab','dataAos' => 'zoom-in','dataToggle' => 'tab','href' => '#nav-profile','role' => 'tab','ariaControls' => 'nav-profile','ariaSelected' => 'false']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => ' ml-2 ','id' => 'nav-profile-tab','data-aos' => 'zoom-in','data-toggle' => 'tab','href' => '#nav-profile','role' => 'tab','aria-controls' => 'nav-profile','aria-selected' => 'false']); ?>Sent <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-2','href' => '#','dataAos' => 'zoom-in','dataToggle' => 'modal','dataTarget' => '#sendmessage']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-2','href' => '#','data-aos' => 'zoom-in','data-toggle' => 'modal','data-target' => '#sendmessage']); ?>Sent Message <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
  </div>
  <hr>
  <br>
</nav>
             
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
  
  <div class="table-responsive ">
  <table class="table email-table no-wrap table-hover v-middle mb-0 font-14">
                                            <tbody>  <h5 class="text-white border bg-dark p-2">Inbox</h5>

                                                <!-- row -->
                                                <?php $__currentLoopData = $inmessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr class="<?php echo e($in->status ? '' : 'font-weight-bold'); ?>" id="inboxhigh">
                                                    <!-- label -->
                                                   
                                                    <!-- star -->
                                                    <td><i class="fa fa-star text-warning"></i></td>
                                                    <td>
                                                        <span class="mb-0 text-muted"><?php echo e($in->name); ?></span>
                                                    </td>
                                                    <!-- Message -->
                                                    <td>
                                                        <a class="link <?php echo e($in->status ? '' : 'toggle-class'); ?>" href="#" data-id="<?php echo e($in->id); ?>" <?php echo e($in->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($in->id); ?>">
                                                            <span class="text-dark"><?php echo e($in->message); ?></span>
                                                        </a>
                                                    </td>
                                                    <?php if($in->path != 1): ?>
                                                    <td>
                                                        <a class="link <?php echo e($in->status ? '' : 'toggle-class'); ?>" href="#" data-id="<?php echo e($in->id); ?>" <?php echo e($in->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($in->id); ?>">
                                                            <span class="text-info"> <i class="fa fa-paperclip" aria-hidden="true"></i> File</span>
                                                        </a>
                                                    </td>
                                                    <?php else: ?>
                                                    <td></td>
                                                    <?php endif; ?>
                                                    <td>
                                                        <a class="link <?php echo e($in->status ? '' : 'toggle-class'); ?>" href="#" data-id="<?php echo e($in->id); ?>" <?php echo e($in->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($in->id); ?>">
                                                            <span class="text-success"><i class="fa fa-eye" aria-hidden="true"></i> View Message</span>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a class="link <?php echo e($in->status ? '' : 'toggle-class'); ?>" href="#" data-toggle="modal" data-target="#deletemessage" data-id="<?php echo e($in->id); ?>" <?php echo e($in->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($in->id); ?>">
                                                            <span class="text-danger"> <i class="fa fa-trash" aria-hidden="true"></i> Delete</span>
                                                        </a>
                                                    </td>
                                                  
                                                    <!-- Attachment -->
                                                    <!-- Time -->
                                                    <td class="text-muted"><?php echo e($in->created_at); ?></td>
                                                </tr>

                                                <div class="modal " id="<?php echo e($in->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Message From <?php echo e($in->name); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body text-black">
                                                        <?php echo e($in->message); ?>

                                                        <br>
                                                        <?php if($in->path != 1): ?>
                                                        <a href="<?php echo e($in->path); ?>" class="text-info" target="blank">View attachment</a>
                                                   <?php endif; ?>
                                                      </div>
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary reply" data-id="<?php echo e($in->from_id); ?>"  data-aos="zoom-in" data-toggle="modal" data-target="#sendmessage" data-aos-anchor="data-aos-anchor">Reply</button>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <!-- row -->
                                                <div class="modal fade" id="deletemessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to delete this message ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a type="button" href="<?php echo e(URL::to('message/' . $in->id . '/delete')); ?>" class="btn btn-primary">Delete</a>
      </div>
    </div>
  </div>
</div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
  
  
  </div>
  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
  
  <div class="table-responsive ">
  <table class="table email-table no-wrap table-hover v-middle mb-0 font-14">
                                            <tbody><h5 class="text-white border bg-dark p-2">Sent Messages</h5>
                                                <!-- row -->
                                                <?php $__currentLoopData = $sendmessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $send): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <!-- label -->
                                                   
                                                    <!-- star -->
                                                    <td><i class="fa fa-star text-warning"></i></td>
                                                    <td>
                                                        <span class="mb-0 text-muted"><?php echo e($send->user->name); ?></span>
                                                    </td>
                                                    <!-- Message -->
                                                    <td>
                                                            <span class="text-dark"><?php echo e($send->message); ?></span>
                                                    </td>
                                                    <?php if($send->path != 1): ?>
                                                    <td>
                                                        <a class="" target="blank" href="<?php echo e($send->path); ?>"  >
                                                            <span class="text-dark"> <i class="fa fa-paperclip" aria-hidden="true"></i> File</span>
                                                        </a>
                                                    </td>
                                                    <?php else: ?>
                                                    <td></td>
                                                    <?php endif; ?>
                                                    <td>
                                                        <a class="link <?php echo e($send->status ? '' : 'toggle-class'); ?>" href="#" data-id="<?php echo e($send->id); ?>" <?php echo e($send->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($send->id); ?>">
                                                            <span class="text-success"><i class="fa fa-eye" aria-hidden="true"></i> View Message</span>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a class="link <?php echo e($send->status ? '' : 'toggle-class'); ?>" href="#" data-toggle="modal" data-target="#deletesendmessage" data-id="<?php echo e($send->id); ?>" <?php echo e($send->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($send->id); ?>">
                                                            <span class="text-danger"> <i class="fa fa-trash" aria-hidden="true"></i> Delete</span>
                                                        </a>
                                                    </td>
                                                    <!-- Attachment -->
                                                    <!-- Time -->
                                                    <td class="text-muted"><?php echo e($send->created_at); ?></td>
                                                </tr>
                                                <!-- row -->
                                                <div class="modal " id="<?php echo e($send->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Message From <?php echo e($send->name); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body text-black">
                                                        <?php echo e($send->message); ?>

                                                        <br>
                                                        <?php if($send->path != 1): ?>
                                                        <a href="<?php echo e($send->path); ?>" class="text-info" target="blank">View attachment</a>
                                                   <?php endif; ?>
                                                      </div>
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary reply" data-id="<?php echo e($send->from_id); ?>"  data-aos="zoom-in" data-toggle="modal" data-target="#sendmessage" data-aos-anchor="data-aos-anchor">Reply</button>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="modal fade" id="deletesendmessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to delete this message ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a type="button" href="<?php echo e(URL::to('message/' . $send->id . '/delete')); ?>" class="btn btn-primary">Delete</a>
      </div>
    </div>
  </div>
</div>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
  
  </div>
  <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">...</div>
</div>
                               
                               
                         
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.sendmessage','data' => ['users' => $users]]); ?>
<?php $component->withName('sendmessage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['users' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users)]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>




<script>
  $(function() {
    $('.toggle-class').click(function() {
        var status = 1; 
        var user_id = $(this).data('id'); 
         
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '/changemesStatus',
            data: {'status': status, 'user_id': user_id},
            success: function(data){
              console.log(status)
              $( '#inboxhigh' ).removeClass( "font-weight-bold" );
              $('.toggle-class').removeClass("toggle-class")
            }
        });
    })
  })

  $(document).on("click", ".reply", function () {
     var myBookId = $(this).data('id');
     $(".formselect").val(myBookId).change();
     console.log(myBookId)
     
     // As pointed out in comments, 
     // it is unnecessary to have to manually call the modal.
     // $('#addBookDialog').modal('show');
});
</script>
<script src="<?php echo e(asset('js/core/popper.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/core/bootstrap.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/now-ui-kit.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/main.js?ver=1.1.0')); ?>"></script>

     <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php /**PATH /home6/hometown/client.hometownsecurity.com.au/profilemanagement/resources/views/message.blade.php ENDPATH**/ ?>