<img src="{{ asset('images/logo.png') }}" width="100px">
