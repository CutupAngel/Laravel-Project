<x-app-layout>
<x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
  
    
    <div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Showing All Sites </h2>
                
                     
               </div>
<div class="container">
  <div class="row">
    <div class="col-12">
      
          <div class="container "> <br><br>
            <table id="examples" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                      <tr>
                        <th scope="col">ID</th>
<th scope="col">SITE NAME</th>



</tr>
                    </thead>
                    <tbody>
                      @foreach($contracts as $contract)
                      <tr>
                          

                        </th>
                        <th scope="row">{{$contract->id}} 
                          <td>{{$contract->cname}}</td>
  
                        <td class="text-white text-right">

                    
                        <a class="btn btn-info smooth-scroll mr-2" href="{{ URL::to('patrol/contract/'.$contract->id) }}"   >Show Actions</a>

                          
                  
                       
                        </td>
                        
                      </tr>


<!-- add notes -->

<!-- add report -->
<div class="modal fade" id="addreport{{$contract->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Report</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="{{ URL::to('clients/' . $contract->id . '/addreport') }}"  enctype="multipart/form-data">
            @csrf
        
          <div class="form-group">
            <label for="message-text" class="col-form-label">Note :</label>
            <textarea class="form-control" name="name" id="message-text"></textarea>
          </div>
          <div class="form-group">
          <!-- <div class="form-check form-switch">
          <label class="form-check-label" for="recipient-name">Monthly Report ? &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</label>
         <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" name="monthly" value="1">
  
</div> -->
          </div>
        
        <br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Report</button>
        </form>
      </div>
    </div>
  </div>
</div>

            @endforeach  
                        </tbody>
                  
                </table>
              
                <br> <br> <br> <br>
                </div>


                <script src="{{ asset('js/core/popper.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/core/bootstrap.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/now-ui-kit.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/aos.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/scripts/main.js?ver=1.1.0')}}"></script>



</x-app-layout>