<x-app-layout >

<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Showing Clients</h2>
                </div>

<div class="container">
  <div class="row">
    <div class="col-12">
      
          <div class="container "> <br><br>
          
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                          <th scope="col">Client Name</th>
                          <th scope="col" class="hidden-sm-down">Actions</th>
                          <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($users as $user)
                      <tr>

                        </th>
                        <td>{{$user->name}} 
                        @if($user->unread >= 1)
                        <a href="/message">
                        <span class="badge ml-3 badge-danger"></i> {{$user->unread}}</span>
                        </a>
                        @endif
                          </td>
                        <td class="text-white hidden-sm-down">
                          <a type="button" href="{{ URL::to('client/' . $user->id ) }}" class="btn btn-info ">Show <i class="icon-eye-open"></i></a>
                          <a type="button" href="{{ URL::to('clients/' . $user->id . '/delete') }}" class="btn btn-danger">Delete <i class="icon-pencil"></i></a>

                          @if(Auth::user()->role == 'admina')
            
                          <a type="button" href="{{ URL::to('clients/' . $user->id . '/edit') }}" class="btn btn-outline-secondary">Edit <i class="icon-edit"></i></a>
            
                          <a type="button" href="{{ URL::to('clients/' . $user->id . '/delete') }}" class="btn btn-outline-secondary">Delete <i class="icon-pencil"></i></a>
                          
                       @endif
                       
                        </td>
                        <td>  
                          <label class="switch">
                            <input data-id="{{$user->id}}" type="checkbox" class="toggle-class" data-toggle="toggle" data-on="Active" data-off="InActive" {{ $user->status ? 'checked' : '' }}>
                            <span class="slider round"></span>
                          </label>                   
                        </td>
                      </tr>
            @endforeach  
                        </tbody>
                  
                </table>
                <br> <br> <br> <br>
                </div>
  
       
    </div>
  </div>
</div>
@if($messages >= 1)
<script>
$('.mgs').removeClass('d-none');

$('.mgs').text(<?php echo json_encode($messages) ?>);

</script>
@endif
<script>
  $(function() {
    $('.toggle-class').change(function() {
        var status = $(this).prop('checked') == true ? 1 : 0; 
        var user_id = $(this).data('id'); 
         
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '/changeStatus',
            data: {'status': status, 'user_id': user_id},
            success: function(data){
              console.log(data.success)
            }
        });
    })
  })
</script>
<script src="{{ asset('js/core/popper.min.js?ver=1.1.0')}}"></script>
<script src="{{ asset('js/core/bootstrap.min.js?ver=1.1.0')}}"></script>
<script src="{{ asset('js/now-ui-kit.js?ver=1.1.0')}}"></script>
<script src="{{ asset('js/aos.js?ver=1.1.0')}}"></script>
<script src="{{ asset('js/scripts/main.js?ver=1.1.0')}}"></script>
</x-app-layout>
