<x-app-layout>
<div class="container">
<div class="mt-3">
<h3 class="text-center">Visiting Site</h3> 

<h3 class="text-center">{{$contract->cname}}</h3> 
</div>
<div class="row mt-5">
@if(session()->get('checkin'))
<a type="button"  href="#" disabled class="btn col-md-4 btn-secondary">Checked In at {{session()->get('checkin')}}</a>
@else
<a type="button"  href="{{ URL::to('/checkin/'.$contract->id) }}" class="btn col-md-4 btn-secondary">Check In</a>
@endif
@if(session()->get('report'))
<button type="button" class="btn col-md-3 btn-secondary"  disabled data-toggle="modal" data-target="#addreport" >Report Added</button>
@else
<button type="button" class="btn col-md-3 btn-secondary"  data-toggle="modal" data-target="#addreport" >Add Report</button>
@endif
<a type="button" href="{{ URL::to('/checkout/'.$contract->id) }}" class="btn col-md-4 btn-secondary">Check Out</a>


<!-- add report -->
<div class="modal fade" id="addreport" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Report</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="{{ URL::to('clients/' . $contract->id . '/addreport') }}"  enctype="multipart/form-data">
            @csrf
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Add to report :</label>
            <textarea type="text" name="name" class="form-control" id="recipient-name"></textarea>
          </div>
          <div class="form-group">
        
        <br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Report</button>
        </form>
      </div>
    </div>
  </div>
</div>


</div>


</div>



<script src="{{ asset('js/core/popper.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/core/bootstrap.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/now-ui-kit.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/aos.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/scripts/main.js?ver=1.1.0')}}"></script>



</x-app-layout>
