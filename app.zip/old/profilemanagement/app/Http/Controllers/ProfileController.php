<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Note;
use Illuminate\Database\Eloquent\Builder;

use App\Models\Report;
use App\Models\Message;
use Illuminate\Support\Facades\Hash;

use App\Models\MonthReport;
use File;
use Image;
use Auth;
use Session;
use View;



class ProfileController extends Controller
{
    public function show()
    {
        
        $users = User::where('role','client')->get();
        $messages = Message::where('user_id', Auth::user()->id)->where('status' , 0)->get()->count() ;
       

        // foreach($users as $user){
        //     $unread = 0 ; 
        //     $messages = Message::where('from_id', $user->id)->where('status' , 0)->get() ;

        //     dd($messages->count());

        //     // foreach($messages as $message){
        //     //         if($message->status == 0){
        //     //             $unread = $unread + 1 ;
        //     //                               }
        //     // }

        //     $user->setAttribute('unread', $unread);



        // }


        return view('dashboard', ['users' => $users, 'messages' => $messages]);

    }
    

    public function showclient($id){
        $user = User::find($id);
        $notes = $user->notes;
        $reports = $user->reports;
        $monthlyreports = $user->monthlyreports;

        return view('clientdashboard',['user' => $user, 'notes' => $notes , 'reports' => $reports , 'monthlyreports' => $monthlyreports]); 
    }
    public function changeUserStatus(Request $request)
    {
        $user = User::find($request->user_id);
        $user->status = $request->status;
        $user->save();
  
        return response()->json(['success'=>'User status change successfully.']);
    }

    public function showmy(){
        $user = Auth::user();
        $notes = $user->notes;
        $reports = $user->reports;
        $monthlyreports = $user->monthlyreports;

        $messages = $user->messages;
        $unread = 0 ;
        foreach($messages as $message){
            if($message->status == 0){
                $unread = $unread + 1 ;
                                    }
         }

        $user->setAttribute('unread', $unread);


        return view('clientdashboard',['user' => $user, 'notes' => $notes , 'reports' => $reports , 'monthlyreports' => $monthlyreports]); 
    }

    public function deleteclient($id){
        User::find($id)->delete();
        return redirect()->route('dashboard');    }

    public function editclient(Request $request, $id){
        
        $user = User::findOrFail($id);
        if($request->password && $request->password_confirmation){
            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255',
                'password' => 'string|confirmed|min:8',
                
    
            ]);
        }
     

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            
            

        ]);
         $input = $request->all();

         $user->fill($input)->save();

         Session::flash('flash_message', 'Task successfully added!');

         return redirect()->back();
        }

public function addnote(Request $request, $id){

            $note = Note::create([

                'date' => $request->date,
                'note' => $request->note,
                'contract_id' => $id,
                'admin_id' => Auth::user()->id 
                
                ]);
                Session::flash('flash_message', 'Note successfully added!');

                return redirect()->back();
           
        }

public function addreport(Request $request, $id){
 
    Session::put('report', $request->name);
   

    
    
   

    Session::flash('flash_message', 'Report successfully added!');

    return redirect()->back();
    
        }
        
public function changepassword(Request $request, $id){

    $request->validate([
        
        'password' => 'required|string|confirmed|min:8',
        

    ]);

    $user = User::find($id);
    $user->update([ 'password' => Hash::make($request->password) ,
    'ps' => 1 ]);

    return redirect()->back();
}
    
}
