<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contract extends Model
{
    use HasFactory;

    protected $fillable = [
        
        'user_id',
        'status',
        'cterm',
        'cname',
        'price',
        'startdate',
        'address',
        'position',
        'approach',
        'paymentterms',
        'ahname',
        'ahnumber',
        'ex1',
        'ex2'
        
    ];
    public function notes(){
        return $this->hasMany(Note::class);
    }

    public function reports(){
        return $this->hasMany(Report::class);
    }

    public function monthlyreports(){
        return $this->hasMany(MonthReport::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    
}
