<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'checkin',
        'contract_id',
        'admin_id',
        'checkout'
    ];
    public function contract()
    {
        return $this->belongsTo(Contract::class);
    }
}
