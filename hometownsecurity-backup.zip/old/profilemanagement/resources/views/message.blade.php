<x-app-layout>
    <x-slot name="header">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Dashboard') }}
            </h2>
        </x-slot>

        <div class="container   mb-1 mt-5 ">
            <div class=" row">
                <div class="col-md-12 col-lg-12">
                        <div class="  text-center">
                            <h2 class="text-black ">Your Mailbox</h2>
                            <x-auth-validation-errors class="mb-4" :errors="$errors" />

  
<nav>
  <div class="nav nav" id="nav-tab" role="tablist">
    <div class="d-flex">
    <x-button class="   " id="nav-home-tab" data-aos="zoom-in" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">In box</x-botton>
    <x-button class=" ml-2 " id="nav-profile-tab" data-aos="zoom-in" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Sent</x-button>
    <x-button class="ml-2" href="#" data-aos="zoom-in" data-toggle="modal" data-target="#sendmessage" >Sent Message</x-button>
    </div>
  </div>
  <hr>
  <br>
</nav>
             
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
  
  <div class="table-responsive ">
  <table class="table email-table no-wrap table-hover v-middle mb-0 font-14">
                                            <tbody>  <h5 class="text-white border bg-dark p-2">Inbox</h5>

                                                <!-- row -->
                                                @foreach($inmessages as $in)

                                                <tr class="{{ $in->status ? '' : 'font-weight-bold' }}" id="inboxhigh">
                                                    <!-- label -->
                                                   
                                                    <!-- star -->
                                                    <td><i class="fa fa-star text-warning"></i></td>
                                                    <td>
                                                        <span class="mb-0 text-muted">{{$in->name}}</span>
                                                    </td>
                                                    <!-- Message -->
                                                    <td>
                                                        <a class="link {{ $in->status ? '' : 'toggle-class' }}" href="#" data-id="{{$in->id}}" {{ $in->status ? 'checked' : '' }} data-toggle="modal" data-target="#{{$in->id}}">
                                                            <span class="text-dark">{{$in->message}}</span>
                                                        </a>
                                                    </td>
                                                    @if($in->path != 1)
                                                    <td>
                                                        <a class="link {{ $in->status ? '' : 'toggle-class' }}" href="#" data-id="{{$in->id}}" {{ $in->status ? 'checked' : '' }} data-toggle="modal" data-target="#{{$in->id}}">
                                                            <span class="text-info"> <i class="fa fa-paperclip" aria-hidden="true"></i> File</span>
                                                        </a>
                                                    </td>
                                                    @else
                                                    <td></td>
                                                    @endif
                                                    <td>
                                                        <a class="link {{ $in->status ? '' : 'toggle-class' }}" href="#" data-id="{{$in->id}}" {{ $in->status ? 'checked' : '' }} data-toggle="modal" data-target="#{{$in->id}}">
                                                            <span class="text-success"><i class="fa fa-eye" aria-hidden="true"></i> View Message</span>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a class="link {{ $in->status ? '' : 'toggle-class' }}" href="#" data-toggle="modal" data-target="#deletemessage" data-id="{{$in->id}}" {{ $in->status ? 'checked' : '' }} data-toggle="modal" data-target="#{{$in->id}}">
                                                            <span class="text-danger"> <i class="fa fa-trash" aria-hidden="true"></i> Delete</span>
                                                        </a>
                                                    </td>
                                                  
                                                    <!-- Attachment -->
                                                    <!-- Time -->
                                                    <td class="text-muted">{{$in->created_at}}</td>
                                                </tr>

                                                <div class="modal " id="{{$in->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Message From {{$in->name}}</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body text-black">
                                                        {{$in->message}}
                                                        <br>
                                                        @if($in->path != 1)
                                                        <a href="{{$in->path}}" class="text-info" target="blank">View attachment</a>
                                                   @endif
                                                      </div>
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary reply" data-id="{{$in->from_id}}"  data-aos="zoom-in" data-toggle="modal" data-target="#sendmessage" data-aos-anchor="data-aos-anchor">Reply</button>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <!-- row -->
                                                <div class="modal fade" id="deletemessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to delete this message ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a type="button" href="{{ URL::to('message/' . $in->id . '/delete') }}" class="btn btn-primary">Delete</a>
      </div>
    </div>
  </div>
</div>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
  
  
  </div>
  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
  
  <div class="table-responsive ">
  <table class="table email-table no-wrap table-hover v-middle mb-0 font-14">
                                            <tbody><h5 class="text-white border bg-dark p-2">Sent Messages</h5>
                                                <!-- row -->
                                                @foreach($sendmessages as $send)

                                                <tr>
                                                    <!-- label -->
                                                   
                                                    <!-- star -->
                                                    <td><i class="fa fa-star text-warning"></i></td>
                                                    <td>
                                                        <span class="mb-0 text-muted">{{$send->user->name}}</span>
                                                    </td>
                                                    <!-- Message -->
                                                    <td>
                                                            <span class="text-dark">{{$send->message}}</span>
                                                    </td>
                                                    @if($send->path != 1)
                                                    <td>
                                                        <a class="" target="blank" href="{{$send->path}}"  >
                                                            <span class="text-dark"> <i class="fa fa-paperclip" aria-hidden="true"></i> File</span>
                                                        </a>
                                                    </td>
                                                    @else
                                                    <td></td>
                                                    @endif
                                                    <td>
                                                        <a class="link {{ $send->status ? '' : 'toggle-class' }}" href="#" data-id="{{$send->id}}" {{ $send->status ? 'checked' : '' }} data-toggle="modal" data-target="#{{$send->id}}">
                                                            <span class="text-success"><i class="fa fa-eye" aria-hidden="true"></i> View Message</span>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a class="link {{ $send->status ? '' : 'toggle-class' }}" href="#" data-toggle="modal" data-target="#deletesendmessage" data-id="{{$send->id}}" {{ $send->status ? 'checked' : '' }} data-toggle="modal" data-target="#{{$send->id}}">
                                                            <span class="text-danger"> <i class="fa fa-trash" aria-hidden="true"></i> Delete</span>
                                                        </a>
                                                    </td>
                                                    <!-- Attachment -->
                                                    <!-- Time -->
                                                    <td class="text-muted">{{$send->created_at}}</td>
                                                </tr>
                                                <!-- row -->
                                                <div class="modal " id="{{$send->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Message From {{$send->name}}</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body text-black">
                                                        {{$send->message}}
                                                        <br>
                                                        @if($send->path != 1)
                                                        <a href="{{$send->path}}" class="text-info" target="blank">View attachment</a>
                                                   @endif
                                                      </div>
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary reply" data-id="{{$send->from_id}}"  data-aos="zoom-in" data-toggle="modal" data-target="#sendmessage" data-aos-anchor="data-aos-anchor">Reply</button>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="modal fade" id="deletesendmessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to delete this message ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a type="button" href="{{ URL::to('message/' . $send->id . '/delete') }}" class="btn btn-primary">Delete</a>
      </div>
    </div>
  </div>
</div>

                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
  
  </div>
  <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">...</div>
</div>
                               
                               
                         
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>

<x-sendmessage :users=$users></x-sendmessage>




<script>
  $(function() {
    $('.toggle-class').click(function() {
        var status = 1; 
        var user_id = $(this).data('id'); 
         
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '/changemesStatus',
            data: {'status': status, 'user_id': user_id},
            success: function(data){
              console.log(status)
              $( '#inboxhigh' ).removeClass( "font-weight-bold" );
              $('.toggle-class').removeClass("toggle-class")
            }
        });
    })
  })

  $(document).on("click", ".reply", function () {
     var myBookId = $(this).data('id');
     $(".formselect").val(myBookId).change();
     console.log(myBookId)
     
     // As pointed out in comments, 
     // it is unnecessary to have to manually call the modal.
     // $('#addBookDialog').modal('show');
});
</script>
<script src="{{ asset('js/core/popper.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/core/bootstrap.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/now-ui-kit.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/aos.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/scripts/main.js?ver=1.1.0')}}"></script>

    </x-app-layout>
    