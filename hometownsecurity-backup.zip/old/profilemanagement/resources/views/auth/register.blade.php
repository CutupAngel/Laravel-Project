<x-app-layout>
       
        <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
            @csrf

<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Create User Profile</h2>
                </div>

<div class="container  rounded bg-white mt-5 mb-5">

<x-auth-validation-errors class="mb-4" :errors="$errors" />

  <div class="row align-items-center">
                
      <div class="col-md-12 border-right">
          <div class="p-3 py-5">
             
              <div class="row mt-2">
                
                 
                  <div class="col-md-12"><label class="labels">NAME</label>
                  <input type="text"  name="name" class="form-control" value="" placeholder="CLIENT NAME"></div>
                 
                  <div class="col-md-12 mt-2"><label class="labels">EMAIL</label>
                  <input type="text" name="email" class="form-control" placeholder="CLIENT EMAIL" value=""></div>
                 
                  <div class="col-md-12 mt-2"><label class="labels">ADDRESS</label>
                  <input type="text" name="address" class="form-control" placeholder="CLIENT ADDRESS" value=""></div>
              </div>
              <br>
              <hr>

              <div class="row mt-3">
                  <div class="col-md-6"><label class="labels">PASSWORD</label><input required type="password" name="password" class="form-control" placeholder="PASSWORD" value=""></div>
                  <div class="col-md-6"><label class="labels">CONFIRM PASSWORD</label><input type="password" id="password_confirmation" name="password_confirmation" class="form-control" value="" placeholder="RE TYPE PASSWORD" required></div>
              </div>
              <hr>
              <div class="row mt-3">
              <div class="col-md-6"></div>
              <div class="col-md-6"><label class="labels">Profile Image</label><input type="file" name="image" class="form-control"></div>
</div>
          </div>
          
      </div>
     
      
  </div>

  
  <div class="flex items-center justify-end mt-4 mb-5">
               
  <div class="d-flex">
  <div class="form-check mt-2">
          <label class="form-check-label font-weight-bold  text-danger" for="recipient-name ">Make This As Admin ? &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</label>
         <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" name="admin" value="1">
  
</div>

               <x-button class="ml-4 mb-5">
                   {{ __('Add User') }}
               </x-button>
               </div>         
           </div>
</div>

</div>

</div>


</form>



</x-app-layout>
