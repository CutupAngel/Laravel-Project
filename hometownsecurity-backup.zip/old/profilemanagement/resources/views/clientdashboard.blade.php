<x-app-layout>



<x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
    
<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Showing Sites of {{$user->name}} </h2>
                
                     @if(Auth::user()->role == 'admin')     
                                     <x-button class=" smooth-scroll mr-2"  data-toggle="modal" data-target="#editform" >CREATE SITES</x-button>
                   
          @endif
               </div>
<div class="container">
  <div class="row">
    <div class="col-12">
      
          <div class="container "> <br><br>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                      <tr>
                        <th scope="col">ID</th>
<th scope="col">SITE NAME</th>



</tr>
                    </thead>
                    <tbody>
                      @foreach($user->contracts as $contract)
                      <tr>
                          

                        </th>
                        <th scope="row">{{$contract->id}} 
                          <td>{{$contract->cname}}</td>
  
                        <td class="text-white text-right">

                          <a type="button" href="{{ URL::to('contract/' . $contract->id ) }}" class="btn btn-outline-secondary ">Show <i class="icon-eye-open"></i></a>
                          @if($user->unread >= 1)
                          <a type="button" href="{{ URL::to('message') }}" class="btn btn-outline-secondary"> </i> New Messages - {{$user->unread}}
                        </a>
                        @endif

           
                       
                          
                  
                       
                        </td>
                        
                      </tr>
            @endforeach  
                        </tbody>
                  
                </table>
              
                <br> <br> <br> <br>
                </div>


<!-- add notes -->
<div class="modal fade" id="newpassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Please Change Your Psssword</h5>

      </div>

      <div class="modal-body">
      <x-auth-validation-errors class="mb-4" :errors="$errors" />

      <form method="POST" action="{{ URL::to('clients/' . $user->id . '/newpassword') }}">
            @csrf
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">New Password :</label>
            <input type="password" name="password" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Re Enter :</label>
            <input type="password" name="password_confirmation" class="form-control" id="recipient-name">
          </div>
         
        
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
      </div>
    </div>
  </div>
</div>



  
<!-- Modal edit -->
<div class="modal mod fade bd-example-modal-lg" id="editform" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="#editform" aria-label="Close">
        </button>
      </div>
      <div class="modal-body">
        

      <form method="POST" action="{{ URL::to('clients/' . $user->id . '/add') }}" enctype="multipart/form-data">
            @csrf

            
 
<div class="justify-content-between text-center align-items-center  mt-1 col-md-12">
                     <h2 class="text-center"> Add Contract to {{$user->name}}'s Profile </h2>
                     <div class="cc-profile-image"><a ><img src="{{$user->image}}" alt="Image"/></a></div>
                </div>

<div class="container rounded bg-white ">

<x-auth-validation-errors class="mb-1" :errors="$errors" />

  <div class="row align-items-center">
                
      <div class="col-md-12 border-right">
          <div class="p-3 py-5">

              <div class="row mt-2">
                 
                  <div class="col-md-6"><label class="labels">CONTRACT TERM</label><input type="text"  name="cterm" class="form-control" value="" placeholder="CONTRACT TERM"></div>
                  <div class="col-md-6"><label class="labels">PRICE PER CHECK</label><input type="text"  name="price" class="form-control" placeholder="PRICE PER CHECK" value=""></div>
              </div>
              <div class="row mt-3">
                 
                  <div class="col-md-6"><label class="labels">CONTRACT START DATE</label><input type="text"  name="startdate" class="form-control" placeholder="CONTRACT START DATE" value=""></div>
                  <!-- <div class="col-md-6"><label class="labels">CLIENT ADDRESS</label><input type="text"  name="address" class="form-control" placeholder="CLIENT ADDRESS" value=""></div> -->
                  <!-- <div class="col-md-6"><label class="labels">CLIENT EMAIL</label><input type="text"  name="email" class="form-control" placeholder="CLIENT EMAIL" value=""></div> -->
                  <div class="col-md-6"><label class="labels">SITE NAME</label><input type="text" name="name" class="form-control" placeholder="CONTRACT NAME" value=""></div>
                  <div class="col-md-6"><label class="labels">CONTACT POSITION</label><input type="text" name="position" class="form-control" placeholder="CONTRACT POSITION" value=""></div>
                  <div class="col-md-6"><label class="labels">APPROACH</label><input type="text" name="approach" class="form-control" placeholder="APPROACH" value=""></div>
                  <div class="col-md-4 mt-2"><label class="labels">PAYMENT TERMS</label><input type="text" name="paymentterms" class="form-control" placeholder="PAYMENT TERMS" value=""></div>
                  <div class="col-md-4 mt-2"><label class="labels">AFTERHOURS CONTACT NAME</label><input type="text" name="ahname" class="form-control" placeholder="CONTRACT NAME" value=""></div>
                  <div class="col-md-4 mt-2"><label class="labels">AFTERHOURS CONTACT NUMBER</label><input type="text" name="ahnumber" class="form-control" placeholder="CONTRACT NAME" value=""></div>

              </div>
              
              <div class="row mt-3">
              <div class="col-md-4 text-right">          
</div>
              <!-- <div class="col-md-8"></br><label class="labels">Upload New Profile Image</label><input type="file" name="image" class="form-control"></div> -->
</div>
          </div>
      </div>
     
      
  </div>
  <div class="flex items-center justify-end mt-2">
               
  <x-button type="button" class="btn btn-secondary" data-dismiss="modal">Close</x-button>

               <x-button class="ml-4">
                   {{ __('Add Contract') }}
               </x-button>

           </div>
</div>

</div>

</div>


</form>
            





      </div>
     
    </div>
  </div>
</div>
               
    </div>
  </div>
</div>
@if($user->unread >= 1)

<script>
$('.mgs').removeClass('d-none');

$('.mgs').text(<?php echo json_encode($user->unread) ?>);

</script>
@endif


<script src="{{ asset('js/core/popper.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/core/bootstrap.min.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/now-ui-kit.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/aos.js?ver=1.1.0')}}"></script>
    <script src="{{ asset('js/scripts/main.js?ver=1.1.0')}}"></script>

    @if(Auth::user()->ps == 0)

<script>
console.log("not change password")
$('#newpassword').modal('show'); 
</script>

@endif
</x-app-layout>
