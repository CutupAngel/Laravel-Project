<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="container   mb-1 mt-5 col-md-12">
            <div class=" row">
                <div class="col-md-12 col-lg-12">
                        <div class=" p-3 ">
                            <h2 class="text-black ml-4">Your Mailbox</h2>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

  
<nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <div class="text-center">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => ' ml-3 mr-3 ','id' => 'nav-home-tab','dataToggle' => 'tab','href' => '#nav-home','role' => 'tab','ariaControls' => 'nav-home','ariaSelected' => 'true']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => ' ml-3 mr-3 ','id' => 'nav-home-tab','data-toggle' => 'tab','href' => '#nav-home','role' => 'tab','aria-controls' => 'nav-home','aria-selected' => 'true']); ?>In box <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => ' ml-3 ','id' => 'nav-profile-tab','dataToggle' => 'tab','href' => '#nav-profile','role' => 'tab','ariaControls' => 'nav-profile','ariaSelected' => 'false']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => ' ml-3 ','id' => 'nav-profile-tab','data-toggle' => 'tab','href' => '#nav-profile','role' => 'tab','aria-controls' => 'nav-profile','aria-selected' => 'false']); ?>Send <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => ' ml-3','href' => '#','dataAos' => 'zoom-in','dataToggle' => 'modal','dataTarget' => '#sendmessage','dataAosAnchor' => 'data-aos-anchor']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => ' ml-3','href' => '#','data-aos' => 'zoom-in','data-toggle' => 'modal','data-target' => '#sendmessage','data-aos-anchor' => 'data-aos-anchor']); ?>Send Message <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
  </div>
  </div>
  <hr>
  <br>
</nav>
             
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
  
  <div class="table-responsive ml-4">
  <h5>Inbox</h5>
  <table class="table email-table no-wrap table-hover v-middle mb-0 font-14">
                                            <tbody>
                                                <!-- row -->
                                                <?php $__currentLoopData = $inmessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr class="<?php echo e($in->status ? '' : 'font-weight-bold'); ?>" id="inboxhigh">
                                                    <!-- label -->
                                                   
                                                    <!-- star -->
                                                    <td><i class="fa fa-star text-warning"></i></td>
                                                    <td>
                                                        <span class="mb-0 text-muted"><?php echo e($in->name); ?></span>
                                                    </td>
                                                    <!-- Message -->
                                                    <td>
                                                        <a class="link <?php echo e($in->status ? '' : 'toggle-class'); ?>" href="#" data-id="<?php echo e($in->id); ?>" <?php echo e($in->status ? 'checked' : ''); ?> data-toggle="modal" data-target="#<?php echo e($in->id); ?>">
                                                            <span class="text-dark"><?php echo e($in->message); ?></span>
                                                        </a>
                                                    </td>
                                                    <!-- Attachment -->
                                                    <!-- Time -->
                                                    <td class="text-muted"><?php echo e($in->created_at); ?></td>
                                                </tr>
                                                <div class="modal fade" id="<?php echo e($in->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Message From <?php echo e($in->name); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body">
                                                        <?php echo e($in->message); ?>

                                                      </div>
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary reply" data-id="<?php echo e($in->from_id); ?>"  data-aos="zoom-in" data-toggle="modal" data-target="#sendmessage" data-aos-anchor="data-aos-anchor">Reply</button>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <!-- row -->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
  
  
  </div>
  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
  
  <div class="table-responsive ml-4">
  <h5>Send Box</h5>
  <table class="table email-table no-wrap table-hover v-middle mb-0 font-14">
                                            <tbody>
                                                <!-- row -->
                                                <?php $__currentLoopData = $sendmessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $send): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <!-- label -->
                                                   
                                                    <!-- star -->
                                                    <td><i class="fa fa-star text-warning"></i></td>
                                                    <td>
                                                        <span class="mb-0 text-muted"><?php echo e($send->user->name); ?></span>
                                                    </td>
                                                    <!-- Message -->
                                                    <td>
                                                        <a class="link toggle-class" href="#" >
                                                            <span class="text-dark"><?php echo e($send->message); ?></span>
                                                        </a>
                                                    </td>
                                                    <!-- Attachment -->
                                                    <!-- Time -->
                                                    <td class="text-muted"><?php echo e($send->created_at); ?></td>
                                                </tr>
                                                <!-- row -->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
  
  </div>
  <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">...</div>
</div>
                               
                               
                         
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>

<!-- add notes -->
<div class="modal fade" id="sendmessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send Message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

     

      <div class="modal-body">
      <form method="POST" action="<?php echo e(URL::to('sendmessage')); ?>">
      <?php echo csrf_field(); ?>
      <div class="form-group">
      <label for="recipient-name" class="col-form-label">To :</label>
      <?php if(Auth::user()->role == 'admin'): ?>  
      <select name="client" class="form-select border-0 form-select-sm ml-5 formselect"  aria-label=".form-select-sm example">
  <option value="" selected > Select Client</option>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php else: ?>
<input type="text" class="form-control" name="client" value=Admin readonly  id="message-text"/>
    <?php endif; ?>
              </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Message :</label>
            <textarea class="form-control" name="message" id="message-text"></textarea>
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Send</button>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  $(function() {
    $('.toggle-class').click(function() {
        var status = 1; 
        var user_id = $(this).data('id'); 
         
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '/changemesStatus',
            data: {'status': status, 'user_id': user_id},
            success: function(data){
              console.log(status)
              $( '#inboxhigh' ).removeClass( "font-weight-bold" );
              $('.toggle-class').removeClass("toggle-class")
            }
        });
    })
  })

  $(document).on("click", ".reply", function () {
     var myBookId = $(this).data('id');
     $(".formselect").val(myBookId).change();
     console.log(myBookId)
     
     // As pointed out in comments, 
     // it is unnecessary to have to manually call the modal.
     // $('#addBookDialog').modal('show');
});
</script>
<script src="<?php echo e(asset('js/core/popper.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/core/bootstrap.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/now-ui-kit.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/main.js?ver=1.1.0')); ?>"></script>

     <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php /**PATH E:\client dashboard\profilemanagement\resources\views/message.blade.php ENDPATH**/ ?>