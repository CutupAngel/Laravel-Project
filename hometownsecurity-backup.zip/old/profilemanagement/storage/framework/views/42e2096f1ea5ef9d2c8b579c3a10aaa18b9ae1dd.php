<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<div class="container">
<div class="mt-3">
<h3 class="text-center">Visiting Site</h3> 

<h3 class="text-center"><?php echo e($contract->cname); ?></h3> 
</div>
<div class="row mt-5">
<?php if(session()->get('checkin')): ?>
<a type="button"  href="#" disabled class="btn col-md-4 btn-secondary">Checked In at <?php echo e(session()->get('checkin')); ?></a>
<?php else: ?>
<a type="button"  href="<?php echo e(URL::to('/checkin/'.$contract->id)); ?>" class="btn col-md-4 btn-secondary">Check In</a>
<?php endif; ?>
<?php if(session()->get('report')): ?>
<button type="button" class="btn col-md-3 btn-secondary"  disabled data-toggle="modal" data-target="#addreport" >Report Added</button>
<?php else: ?>
<button type="button" class="btn col-md-3 btn-secondary"  data-toggle="modal" data-target="#addreport" >Add Report</button>
<?php endif; ?>
<a type="button" href="<?php echo e(URL::to('/checkout/'.$contract->id)); ?>" class="btn col-md-4 btn-secondary">Check Out</a>


<!-- add report -->
<div class="modal fade" id="addreport" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Report</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="<?php echo e(URL::to('clients/' . $contract->id . '/addreport')); ?>"  enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Add to report :</label>
            <textarea type="text" name="name" class="form-control" id="recipient-name"></textarea>
          </div>
          <div class="form-group">
        
        <br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Report</button>
        </form>
      </div>
    </div>
  </div>
</div>


</div>


</div>



<script src="<?php echo e(asset('js/core/popper.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/core/bootstrap.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/now-ui-kit.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/main.js?ver=1.1.0')); ?>"></script>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home6/hometown/client.hometownsecurity.com.au/profilemanagement/resources/views/patrolcon.blade.php ENDPATH**/ ?>