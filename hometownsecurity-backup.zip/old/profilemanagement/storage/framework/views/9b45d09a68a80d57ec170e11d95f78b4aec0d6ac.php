<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Showing Contracts of <?php echo e($user->name); ?> </h2>
                
                     <?php if(Auth::user()->role == 'admin'): ?>     
                                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => ' smooth-scroll mr-2','dataToggle' => 'modal','dataTarget' => '#editform']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => ' smooth-scroll mr-2','data-toggle' => 'modal','data-target' => '#editform']); ?>CREATE CONTRACT <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                   
          <?php endif; ?>
               </div>
<div class="container">
  <div class="row">
    <div class="col-12">
      
          <div class="container "> <br><br>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                      <tr>
                        <th scope="col">ID</th>
<th scope="col">CONTRACT NAME</th>



</tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $user->contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          

                        </th>
                        <th scope="row"><?php echo e($contract->id); ?> 
                          <td><?php echo e($contract->cname); ?></td>
  
                        <td class="text-white text-right">

                          <a type="button" href="<?php echo e(URL::to('contract/' . $contract->id )); ?>" class="btn btn-outline-secondary ">Show <i class="icon-eye-open"></i></a>
            
                          <!-- <a type="button" href="<?php echo e(URL::to('contract/' . $contract->id . '/edit')); ?>" class="btn btn-outline-secondary">Edit <i class="icon-edit"></i></a> -->
            <?php if(Auth::user()->role == 'admin'): ?>
            
            <a type="button" href="<?php echo e(URL::to('contract/' . $contract->id . '/delete')); ?>" class="btn btn-outline-secondary">Delete <i class="icon-pencil"></i></a>

                          
                       <?php endif; ?>
                       
                          
                  
                       
                        </td>
                        
                      </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </tbody>
                  
                </table>
              
                <br> <br> <br> <br>
                </div>
  
<!-- Modal edit -->
<div class="modal mod fade bd-example-modal-lg" id="editform" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="#editform" aria-label="Close">
        </button>
      </div>
      <div class="modal-body">
        

      <form method="POST" action="<?php echo e(URL::to('clients/' . $user->id . '/add')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            
 
<div class="justify-content-between text-center align-items-center  mt-1 col-md-12">
                     <h2 class="text-center"> Add Contract to <?php echo e($user->name); ?>'s Profile </h2>
                     <div class="cc-profile-image"><a ><img src="<?php echo e($user->image); ?>" alt="Image"/></a></div>
                </div>

<div class="container rounded bg-white ">

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-1','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-1','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

  <div class="row align-items-center">
                
      <div class="col-md-12 border-right">
          <div class="p-3 py-5">

              <div class="row mt-2">
                 
                  <div class="col-md-6"><label class="labels">CONTRACT TERM</label><input type="text"  name="cterm" class="form-control" value="" placeholder="CONTRACT TERM"></div>
                  <div class="col-md-6"><label class="labels">PRICE PER CHECK</label><input type="text"  name="price" class="form-control" placeholder="PRICE PER CHECK" value=""></div>
              </div>
              <div class="row mt-3">
                 
                  <div class="col-md-6"><label class="labels">CONTRACT START DATE</label><input type="text"  name="startdate" class="form-control" placeholder="CONTRACT START DATE" value=""></div>
                  <!-- <div class="col-md-6"><label class="labels">CLIENT ADDRESS</label><input type="text"  name="address" class="form-control" placeholder="CLIENT ADDRESS" value=""></div> -->
                  <!-- <div class="col-md-6"><label class="labels">CLIENT EMAIL</label><input type="text"  name="email" class="form-control" placeholder="CLIENT EMAIL" value=""></div> -->
                  <div class="col-md-6"><label class="labels">CONTACT NAME</label><input type="text" name="name" class="form-control" placeholder="CONTRACT NAME" value=""></div>
                  <div class="col-md-6"><label class="labels">CONTACT POSITION</label><input type="text" name="position" class="form-control" placeholder="CONTRACT POSITION" value=""></div>
                  <div class="col-md-6"><label class="labels">APPROACH</label><input type="text" name="approach" class="form-control" placeholder="APPROACH" value=""></div>
                  <div class="col-md-4 mt-2"><label class="labels">PAYMENT TERMS</label><input type="text" name="paymentterms" class="form-control" placeholder="PAYMENT TERMS" value=""></div>
                  <div class="col-md-4 mt-2"><label class="labels">AFTERHOURS CONTACT NAME</label><input type="text" name="ahname" class="form-control" placeholder="CONTRACT NAME" value=""></div>
                  <div class="col-md-4 mt-2"><label class="labels">AFTERHOURS CONTACT NUMBER</label><input type="text" name="ahnumber" class="form-control" placeholder="CONTRACT NAME" value=""></div>

              </div>
              
              <div class="row mt-3">
              <div class="col-md-4 text-right">          
</div>
              <!-- <div class="col-md-8"></br><label class="labels">Upload New Profile Image</label><input type="file" name="image" class="form-control"></div> -->
</div>
          </div>
      </div>
     
      
  </div>
  <div class="flex items-center justify-end mt-2">
               
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['type' => 'button','class' => 'btn btn-secondary','dataDismiss' => 'modal']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'button','class' => 'btn btn-secondary','data-dismiss' => 'modal']); ?>Close <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

               <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-4']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4']); ?>
                   <?php echo e(__('Add Contract')); ?>

                <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

           </div>
</div>

</div>

</div>


</form>
            





      </div>
     
    </div>
  </div>
</div>
               
    </div>
  </div>
</div>

<script src="<?php echo e(asset('js/core/popper.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/core/bootstrap.min.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/now-ui-kit.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js?ver=1.1.0')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/main.js?ver=1.1.0')); ?>"></script>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\client dashboard\profilemanagement\resources\views/clientdashboard.blade.php ENDPATH**/ ?>