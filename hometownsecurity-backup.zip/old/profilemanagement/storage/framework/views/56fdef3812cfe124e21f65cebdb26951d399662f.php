<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Showing Clients</h2>
                </div>

<div class="container">
  <div class="row">
    <div class="col-12">
      
          <div class="container "> <br><br>
          
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                          <th scope="col">Client Name</th>
                          <th scope="col" class="hidden-sm-down">Actions</th>
                          <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>

                        </th>
                        <td><?php echo e($user->name); ?> <span class="badge badge-danger"><i class="icon-inbox"></i> <?php echo e($user->messages_count); ?></span>
                          </td>
                        <td class="text-white hidden-sm-down">
                          <a type="button" href="<?php echo e(URL::to('client/' . $user->id )); ?>" class="btn btn-outline-secondary ">Show <i class="icon-eye-open"></i></a>
                          <?php if(Auth::user()->role == 'admina'): ?>
            
                          <a type="button" href="<?php echo e(URL::to('clients/' . $user->id . '/edit')); ?>" class="btn btn-outline-secondary">Edit <i class="icon-edit"></i></a>
            
                          <a type="button" href="<?php echo e(URL::to('clients/' . $user->id . '/delete')); ?>" class="btn btn-outline-secondary">Delete <i class="icon-pencil"></i></a>
                          
                       <?php endif; ?>
                       
                        </td>
                        <td>  
                          <label class="switch">
                            <input data-id="<?php echo e($user->id); ?>" type="checkbox" class="toggle-class" data-toggle="toggle" data-on="Active" data-off="InActive" <?php echo e($user->status ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                          </label>                   
                        </td>
                      </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </tbody>
                  
                </table>
                <br> <br> <br> <br>
                </div>
  
       
    </div>
  </div>
</div>
<script>
  $(function() {
    $('.toggle-class').change(function() {
        var status = $(this).prop('checked') == true ? 1 : 0; 
        var user_id = $(this).data('id'); 
         
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '/changeStatus',
            data: {'status': status, 'user_id': user_id},
            success: function(data){
              console.log(data.success)
            }
        });
    })
  })
</script>
<script src="<?php echo e(asset('js/core/popper.min.js?ver=1.1.0')); ?>"></script>
<script src="<?php echo e(asset('js/core/bootstrap.min.js?ver=1.1.0')); ?>"></script>
<script src="<?php echo e(asset('js/now-ui-kit.js?ver=1.1.0')); ?>"></script>
<script src="<?php echo e(asset('js/aos.js?ver=1.1.0')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/main.js?ver=1.1.0')); ?>"></script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\client dashboard\profilemanagement\resources\views/dashboard.blade.php ENDPATH**/ ?>