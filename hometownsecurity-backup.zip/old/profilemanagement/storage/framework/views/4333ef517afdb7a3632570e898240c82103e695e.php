<img src="<?php echo e(asset('images/logo.png')); ?>" width="100px">
<?php /**PATH E:\client dashboard\profilemanagement\resources\views/components/application-logo.blade.php ENDPATH**/ ?>