<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<h2> Report </h2>

<table>
  <tr>
    <th>Date</th>
    <th>Note</th>
  </tr>

<?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td> <?php echo e($week->created_at); ?></td>
    <td><?php echo e($week->name); ?></td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table><?php /**PATH /home6/hometown/client.hometownsecurity.com.au/profilemanagement/resources/views/pdf.blade.php ENDPATH**/ ?>