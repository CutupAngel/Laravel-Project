<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contract;
use App\Models\User;
use App\Models\Report;
use Auth;

use Session;
use Carbon\Carbon;
use PDF;


class ContractController extends Controller
{
    public function addcontract(Request $request, $id)
    {
        $Contract = Contract::create([
           
            'user_id' => $id,
            'cterm' => $request->cterm,
            'price' =>  $request->price,
            'startdate' => $request->startdate,
            'position' => $request->position,
            'cname' => $request->name,
            'approach' => $request->approach,
            'paymentterms' => $request->paymentterms,
            'ahname' => $request->ahname,
            'ahnumber' => $request->ahnumber,
            
        ]);



        return redirect()->back();
    }

    public function showcontract($id){
             
            $contract = Contract::find($id);
            $user = User::find($contract->user_id);
            $notes = $contract->notes;
            $reports = $contract->reports;
            
            $weekly = $reports->groupBy(function($date) {
                return Carbon::parse($date->created_at)->format('W');
            });

            $monthly = $reports->groupBy(function($date) {
                return Carbon::parse($date->created_at)->format('M');
            });

            $dates =[];
            foreach($weekly as $weeks){
                    $startdate = $weeks[0]->created_at->format('d M Y');
                    $enddate = $weeks[count($weeks)-1]->created_at->format('d M Y');
                  

                    $date = $startdate." - ".$enddate ;
                    $dates[]=$date;
                
            }
            $datesm =[];
            foreach($monthly as $months){
                    $startdate = $months[0]->created_at->format('d M Y');
                    $enddate = $months[count($months)-1]->created_at->format('d M Y');
                  

                    $date = $startdate." - ".$enddate ;
                    $datesm[]=$date;
                
            }
            $monthlyreports = $contract->monthlyreports;


            return view('welcome',['user' => $user ,'contract' => $contract, 'notes' => $notes , 'reports' => $dates , 'monthlyreports' => $datesm]); 
        
    }

   public function pdfdownload($id,$cid){

$contract = Contract::find($cid);
$user = User::find($contract->user_id);
$notes = $contract->notes;
$reports = $contract->reports;

$weekly = $reports->groupBy(function($date) {
    return Carbon::parse($date->created_at)->format('W');
});


$weekcount = -1;
foreach($weekly as $weeks){
    $weekcount = $weekcount + 1;

    if($weekcount == $id){
    return view('pdf',['weeks'=>$weeks]);
    view()->share('weeks', $weeks);
    $pdf = PDF::loadView('pdf');
    return $pdf->download('pdf.pdf');

}
}
}

public function pdfdownloadm($id,$cid){

    $contract = Contract::find($cid);
    $user = User::find($contract->user_id);
    $notes = $contract->notes;
    $reports = $contract->reports;

    
    $monthly = $reports->groupBy(function($date) {
        return Carbon::parse($date->created_at)->format('M');
    });
    
    
    $monthcount = -1;
    foreach($monthly as $months){
        $monthcount = $monthcount + 1;
    
        if($monthcount == $id){
        view()->share('weeks', $months);
        $pdf = PDF::loadView('pdf');
        return $pdf->download('pdf.pdf');
    
    }
    }
    }
    public function deletecontract($id){
        Contract::find($id)->delete();
        return redirect()->route('dashboard');    }

    
    public function contractedit(Request $request, $id){
        $contract = Contract::findOrFail($id);

         $input = $request->all();
         $contract->fill($input)->save();

         Session::flash('flash_message', 'Task successfully added!');

         return redirect()->back();
        }

        public function addnote(Request $request, $id){

            $note = Note::create([

                'date' => $request->date,
                'note' => $request->note,
                'contract_id' => $id,
                'admin_id' => Auth::user()->id 
                
                ]);
                Session::flash('flash_message', 'Note successfully added!');

                return redirect()->back();
           
        }
        public function patrol(){
            $contracts = Contract::all();
    
            return view('patroldashboard',['contracts' =>  $contracts, ]); 
        }

        public function viewsite($id){
            
            $contract = Contract::findOrfail($id);

    return view('patrolcon',['contract' =>$contract  ]);
        }

        public function checkin($id){
        
            $now = Carbon::now();
            $date = $now->toDateTimeString();
            Session::put('checkin', $date);
            return redirect()->back();
        }

        public function checkout($id){
        
            $now = Carbon::now();
            $date = $now->toDateTimeString();
           
            $report = Report::create([

                'name' => Session::get('report'),
                'checkin' => Session::get('checkin'),
                'contract_id' => $id,
                'admin_id' => Auth::user()->id ,
                'checkout' => $date
                
                ]);
            Session::forget('checkin');
            Session::forget('report');


                return redirect('patrol');


        }
}

