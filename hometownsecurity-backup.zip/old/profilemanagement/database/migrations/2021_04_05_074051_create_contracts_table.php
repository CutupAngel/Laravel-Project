<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContractsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contracts', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->string('status')->nullable();
            $table->string('cterm')->nullable();
            $table->string('cname')->nullable();
            $table->string('price')->nullable();
            $table->string('startdate')->nullable();
            $table->string('address')->nullable();
            $table->string('position')->nullable();
            $table->string('approach')->nullable();
            $table->string('paymentterms')->nullable();
            $table->string('ahname')->nullable();
            $table->string('ahnumber')->nullable();
            $table->string('ex1')->nullable();
            $table->string('ex2')->nullable();
            

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contracts');
    }
}
