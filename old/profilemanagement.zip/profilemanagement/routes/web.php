<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContractController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\MessageController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

require __DIR__.'/auth.php';

Route::get('/dashboard', [ProfileController::class, 'show'])
                ->middleware('admin')
                ->name('dashboard');
Route::get('/message', [MessageController::class, 'inbox'])
          ->middleware('auth')
          ->name('inbox');

Route::get('/client/{id}', [ProfileController::class, 'showclient'])
->middleware('auth')
->name('client');

Route::get('/contract/{id}', [ContractController::class, 'showcontract'])
->middleware('auth')
->name('contract');

Route::get('/clientm', [ProfileController::class, 'showmy'])
->middleware('client')
->name('clientm');

Route::get('/clients/{id}/delete', [ProfileController::class, 'deleteclient'])
->middleware('admin')
->name('clientdelete');


Route::get('/contract/{id}/delete', [ContractController::class, 'deletecontract'])
->middleware('admin')
->name('contractdelete');

Route::post('/clients/{id}/edit', [ProfileController::class, 'editclient'])
->middleware('admin')
->name('editclient');

Route::post('/contract/{id}/edit', [ContractController::class, 'contractedit'])
->middleware('admin')
->name('editcontract');

Route::post('/clients/{id}/add', [ContractController::class, 'addcontract'])
->middleware('admin')
->name('addcontract');


Route::post('/clients/{id}/addnote', [ProfileController::class, 'addnote'])
->middleware('admin')
->name('addnote');


Route::post('/clients/{id}/addreport', [ProfileController::class, 'addreport'])
->middleware('admin')
->name('addreport');


Route::get('changeStatus', [ProfileController::class, 'ChangeUserStatus']);
Route::get('changemesStatus', [MessageController::class, 'ChangeMessageStatus']);

Route::post('/sendmessage', [MessageController::class, 'send'])
          ->middleware('auth')
          ->name('send');