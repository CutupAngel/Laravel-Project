<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Message;
use Auth;
use Illuminate\Http\Request;
use File;
use Image;

use Session;
use View;
class MessageController extends Controller
{
    public function inbox()
    {
        
        $users = User::where('role','client')->get();

        $sendmessages = Message::where('from_id' , Auth::user()->id )->get();
        $inmessages = Auth::user()->messages;
        foreach($inmessages as $mgs){
            $name = User::find($mgs->from_id)->name ;
          
            $mgs->setAttribute('name', $name);
           
        }
       
        return view('message',['users' => $users , 'sendmessages' => $sendmessages , 'inmessages' => $inmessages]);

    }
public function ChangeMessageStatus(Request $request){
        $user = Message::find($request->user_id);
        $user->status = $request->status;
        $user->save();
  
        return response()->json(['success'=>'User status change successfully.']);
}



public function send(Request $request){
    $random_string = md5(microtime());

if($request->hasFile('file')){ 
$fileName = $random_string.'.'.$request->file->extension(); 
   
$save_path           = storage_path() . '/app/public/messages/' . $request->client;

$path          = $save_path . $fileName ;

$public_path        = '/storage/messages/' . $request->client . '/' . $fileName;

File::makeDirectory($save_path, $mode = 0755, true, true);

$request->file->move($save_path, $fileName);

}

        $request->validate([
            'client' => 'required',
        ]);

        if($request->client == 'Admin'){
            $request->client = 1 ;
        }

        $message = Message::create([
            'user_id' => $request->client,
            'message' => $request->message,
            'status' => 0,
            'from_id' => Auth::user()->id ,
            'path' => $public_path ?? 1

        ]);

        return redirect()->back();    }
}
