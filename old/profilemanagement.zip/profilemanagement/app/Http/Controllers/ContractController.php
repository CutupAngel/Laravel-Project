<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contract;
use App\Models\User;
use Session;

class ContractController extends Controller
{
    public function addcontract(Request $request, $id)
    {
        $Contract = Contract::create([
           
            'user_id' => $id,
            'cterm' => $request->cterm,
            'price' =>  $request->price,
            'startdate' => $request->startdate,
            'position' => $request->position,
            'cname' => $request->name,
            'approach' => $request->approach,
            'paymentterms' => $request->paymentterms,
            'ahname' => $request->ahname,
            'ahnumber' => $request->ahnumber,
            
        ]);



        return redirect()->back();
    }

    public function showcontract($id){
             
            $contract = Contract::find($id);
            $user = User::find($contract->user_id);
            $notes = $contract->notes;
            $reports = $contract->reports;
            $monthlyreports = $contract->monthlyreports;
            return view('welcome',['user' => $user ,'contract' => $contract, 'notes' => $notes , 'reports' => $reports , 'monthlyreports' => $monthlyreports]); 
        
    }

    public function deletecontract($id){
        Contract::find($id)->delete();
        return redirect()->route('dashboard');    }

    
    public function contractedit(Request $request, $id){
        $contract = Contract::findOrFail($id);

         $input = $request->all();

         $contract->fill($input)->save();

         Session::flash('flash_message', 'Task successfully added!');

         return redirect()->back();
        }

        public function addnote(Request $request, $id){

            $note = Note::create([

                'date' => $request->date,
                'note' => $request->note,
                'contract_id' => $id,
                'admin_id' => Auth::user()->id 
                
                ]);
                Session::flash('flash_message', 'Note successfully added!');

                return redirect()->back();
           
        }
}
