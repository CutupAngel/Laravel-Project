<!-- add notes -->
<div class="modal fade" id="sendmessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send Message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

     

      <div class="modal-body">
      <form method="POST" action="{{ URL::to('sendmessage') }}" enctype="multipart/form-data">
      @csrf
      <div class="form-group">
      <label for="recipient-name" class="col-form-label">To :</label>
      @if(Auth::user()->role == 'admin')  
      <select name="client" class="form-select border-0 form-select-sm ml-5 formselect"  aria-label=".form-select-sm example">
  <option value="" selected > Select Client</option>
  @foreach($users as $user)
  <option value="{{$user->id}}">{{$user->name}}</option>
 @endforeach
</select>

@else
<input type="text" class="form-control" name="client" value=Admin readonly  id="message-text"/>
    @endif
              </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Message :</label>
            <textarea class="form-control" name="message" id="message-text"></textarea>
          </div>
        
          <div class="form-group">
            <label for="message-text" class="col-form-label">Attach Document :</label>
            <input type="file" class="form-file" name="file" id="message-text"/>
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Send</button>
        </form>
      </div>
    </div>
  </div>
</div>