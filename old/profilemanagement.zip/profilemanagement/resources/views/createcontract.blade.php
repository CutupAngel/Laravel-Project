<x-app-layout>
       

        <!-- Validation Errors -->

        <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
            @csrf

            <!-- Name -->
            <!-- <div>
                <x-label for="name" :value="__('Name')" />

                <x-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus />
            </div>

            <div class="mt-4">
                <x-label for="email" :value="__('Email')" />

                <x-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required />
            </div>

            <div class="mt-4">
                <x-label for="password" :value="__('Password')" />

                <x-input id="password" class="block mt-1 w-full"
                                type="password"
                                name="password"
                                required autocomplete="new-password" />
            </div>

            <div class="mt-4">
                <x-label for="password_confirmation" :value="__('Confirm Password')" />

                <x-input id="password_confirmation" class="block mt-1 w-full"
                                type="password"
                                name="password_confirmation" required />
            </div> 

            <div class="flex items-center justify-end mt-4">
               

                <x-button class="ml-4">
                    {{ __('Register') }}
                </x-button>
            </div>
-->
 
<div class="justify-content-between text-center align-items-center mb-1 mt-5 col-md-12">
                     <h2 class="text-center">Create Client Profile</h2>
                </div>

<div class="container rounded bg-white mt-5 mb-5">

<x-auth-validation-errors class="mb-4" :errors="$errors" />

  <div class="row align-items-center">
                
      <div class="col-md-12 border-right">
          <div class="p-3 py-5">
             
              <div class="row mt-2">
                  <div class="col-md-6"><label class="labels">CONTACT STATUS</label>
                  <input type="text" name="status" class="form-control" placeholder="CONTACT STATUS" value=""></div>
                  <div class="col-md-6"><label class="labels">CONTRACT TERM</label><input type="text"  name="term" class="form-control" value="" placeholder="CONTRACT TERM"></div>
              </div>
              <div class="row mt-3">
                  <div class="col-md-12"><label class="labels">PRICE PER CHECK</label><input type="text"  name="price" class="form-control" placeholder="PRICE PER CHECK" value=""></div>
                  <div class="col-md-12"><label class="labels">CONTRACT START DATE</label><input type="text"  name="startdate" class="form-control" placeholder="CONTRACT START DATE" value=""></div>
                  <div class="col-md-12"><label class="labels">CLIENT ADDRESS</label><input type="text"  name="address" class="form-control" placeholder="CLIENT ADDRESS" value=""></div>
                  <div class="col-md-12"><label class="labels">CLIENT EMAIL</label><input type="text"  name="email" class="form-control" placeholder="CLIENT EMAIL" value=""></div>
                  <div class="col-md-12"><label class="labels">CONTRACT NAME</label><input type="text" name="name" class="form-control" placeholder="CONTRACT NAME" value=""></div>
                  <div class="col-md-12"><label class="labels">CONTRACT POSITION</label><input type="text" name="position" class="form-control" placeholder="CONTRACT POSITION" value=""></div>
                  <div class="col-md-12"><label class="labels">APPROACH</label><input type="text" name="approach" class="form-control" placeholder="APPROACH" value=""></div>
                  <div class="col-md-12"><label class="labels">PAYMENT TERMS</label><input type="text" name="paymentterms" class="form-control" placeholder="PAYMENT TERMS" value=""></div>
              </div>
              <div class="row mt-3">
                  <div class="col-md-6"><label class="labels">AFTERHOURS CONTRACT NAME</label><input type="text" name="ahname" class="form-control" placeholder="CONTRACT NAME" value=""></div>
                  <div class="col-md-6"><label class="labels">AFTERHOURS CONTRACT NUMBER</label><input type="text" name="ahnumber" class="form-control" value="" placeholder="CONTRACT NUMBER"></div>
              </div>
              <br>
              <hr>

              <div class="row mt-3">
                  <div class="col-md-6"><label class="labels">PASSWORD</label><input required type="password" name="password" class="form-control" placeholder="PASSWORD" value=""></div>
                  <div class="col-md-6"><label class="labels">CONFIRM PASSWORD</label><input type="password" id="password_confirmation" name="password_confirmation" class="form-control" value="" placeholder="RE TYPE PASSWORD" required></div>
              </div>
              <hr>
              <div class="row mt-3">
              <div class="col-md-6"></div>
              <div class="col-md-6"><label class="labels">Profile Image</label><input type="file" name="image" class="form-control"></div>
</div>
          </div>
      </div>
     
      
  </div>
  <div class="flex items-center justify-end mt-4">
               

               <x-button class="ml-4">
                   {{ __('Add Client') }}
               </x-button>
           </div>
</div>

</div>

</div>


</form>



</x-app-layout>
